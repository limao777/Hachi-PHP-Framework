
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/object.h"
#include "kernel/memory.h"
#include "kernel/array.h"
#include "kernel/hash.h"
#include "kernel/fcall.h"
#include "kernel/operators.h"
#include "kernel/string.h"
#include "kernel/file.h"
#include "kernel/require.h"
#include "kernel/exception.h"


ZEPHIR_INIT_CLASS(hachi_0__closure) {

	ZEPHIR_REGISTER_CLASS(hachi, 0__closure, hachi, 0__closure, hachi_0__closure_method_entry, ZEND_ACC_FINAL_CLASS);

	return SUCCESS;

}

PHP_METHOD(hachi_0__closure, __invoke) {

	int ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_3 = NULL;
	zval *class_name = NULL, class_name_sub, is_exclude, t, require_path, exclude, spl_value, _0, *_1, _2$$3, _4$$5, _5$$5, _6$$5, _7$$5, _8$$6, _9$$6, _10$$6, _11$$7, _12$$7, _13$$7, _14$$8, _15$$8, _16$$8;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&class_name_sub);
	ZVAL_UNDEF(&is_exclude);
	ZVAL_UNDEF(&t);
	ZVAL_UNDEF(&require_path);
	ZVAL_UNDEF(&exclude);
	ZVAL_UNDEF(&spl_value);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_4$$5);
	ZVAL_UNDEF(&_5$$5);
	ZVAL_UNDEF(&_6$$5);
	ZVAL_UNDEF(&_7$$5);
	ZVAL_UNDEF(&_8$$6);
	ZVAL_UNDEF(&_9$$6);
	ZVAL_UNDEF(&_10$$6);
	ZVAL_UNDEF(&_11$$7);
	ZVAL_UNDEF(&_12$$7);
	ZVAL_UNDEF(&_13$$7);
	ZVAL_UNDEF(&_14$$8);
	ZVAL_UNDEF(&_15$$8);
	ZVAL_UNDEF(&_16$$8);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &class_name);

	ZEPHIR_SEPARATE_PARAM(class_name);


	zephir_read_static_property_ce(&_0, hachi_app_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	ZEPHIR_OBS_VAR(&exclude);
	zephir_array_fetch_string(&exclude, &_0, SL("spl_exclude"), PH_NOISY, "hachi/app.zep", 31 TSRMLS_CC);
	ZEPHIR_INIT_VAR(&is_exclude);
	ZVAL_BOOL(&is_exclude, 0);
	zephir_is_iterable(&exclude, 0, "hachi/app.zep", 40);
	ZEND_HASH_FOREACH_VAL(Z_ARRVAL_P(&exclude), _1)
	{
		ZEPHIR_INIT_NVAR(&spl_value);
		ZVAL_COPY(&spl_value, _1);
		ZEPHIR_CALL_FUNCTION(&_2$$3, "stripos", &_3, 15, class_name, &spl_value);
		zephir_check_call_status();
		if (!ZEPHIR_IS_FALSE_IDENTICAL(&_2$$3)) {
			ZEPHIR_INIT_NVAR(&is_exclude);
			ZVAL_BOOL(&is_exclude, 1);
			break;
		}
	} ZEND_HASH_FOREACH_END();
	ZEPHIR_INIT_NVAR(&spl_value);
	ZEPHIR_INIT_NVAR(&exclude);
	ZVAL_NULL(&exclude);
	if (!(zephir_is_true(&is_exclude))) {
		ZEPHIR_INIT_VAR(&_4$$5);
		ZEPHIR_INIT_VAR(&_5$$5);
		ZVAL_STRING(&_5$$5, "_");
		ZEPHIR_INIT_VAR(&_6$$5);
		ZVAL_STRING(&_6$$5, "/");
		zephir_fast_str_replace(&_4$$5, &_5$$5, &_6$$5, class_name TSRMLS_CC);
		ZEPHIR_CPY_WRT(class_name, &_4$$5);
		zephir_read_static_property_ce(&_7$$5, hachi_app_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_OBS_VAR(&t);
		zephir_array_fetch_string(&t, &_7$$5, SL("www"), PH_NOISY, "hachi/app.zep", 44 TSRMLS_CC);
		ZEPHIR_INIT_NVAR(&_4$$5);
		ZVAL_STRING(&_4$$5, "%s/%s.php");
		ZEPHIR_CALL_FUNCTION(&require_path, "sprintf", NULL, 7, &_4$$5, &t, class_name);
		zephir_check_call_status();
		if ((zephir_file_exists(&require_path TSRMLS_CC) == SUCCESS)) {
			if (zephir_require_zval(&require_path TSRMLS_CC) == FAILURE) {
				RETURN_MM_NULL();
			}
			ZEPHIR_INIT_VAR(&_8$$6);
			ZEPHIR_INIT_VAR(&_9$$6);
			ZVAL_STRING(&_9$$6, "/");
			ZEPHIR_INIT_VAR(&_10$$6);
			ZVAL_STRING(&_10$$6, "_");
			zephir_fast_str_replace(&_8$$6, &_9$$6, &_10$$6, class_name TSRMLS_CC);
			ZEPHIR_CPY_WRT(class_name, &_8$$6);
			if (!(zephir_class_exists(class_name, 1 TSRMLS_CC))) {
				ZEPHIR_INIT_VAR(&_11$$7);
				object_init_ex(&_11$$7, zend_exception_get_default(TSRMLS_C));
				ZEPHIR_INIT_VAR(&_12$$7);
				ZVAL_STRING(&_12$$7, "Found class error: %s");
				ZEPHIR_CALL_FUNCTION(&_13$$7, "sprintf", NULL, 7, &_12$$7, class_name);
				zephir_check_call_status();
				ZEPHIR_CALL_METHOD(NULL, &_11$$7, "__construct", NULL, 12, &_13$$7);
				zephir_check_call_status();
				zephir_throw_exception_debug(&_11$$7, "hachi/app.zep", 50 TSRMLS_CC);
				ZEPHIR_MM_RESTORE();
				return;
			}
		} else {
			ZEPHIR_INIT_VAR(&_14$$8);
			object_init_ex(&_14$$8, zend_exception_get_default(TSRMLS_C));
			ZEPHIR_INIT_VAR(&_15$$8);
			ZVAL_STRING(&_15$$8, "Not Found class : %s");
			ZEPHIR_CALL_FUNCTION(&_16$$8, "sprintf", NULL, 7, &_15$$8, class_name);
			zephir_check_call_status();
			ZEPHIR_CALL_METHOD(NULL, &_14$$8, "__construct", NULL, 12, &_16$$8);
			zephir_check_call_status();
			zephir_throw_exception_debug(&_14$$8, "hachi/app.zep", 53 TSRMLS_CC);
			ZEPHIR_MM_RESTORE();
			return;
		}
	}
	ZEPHIR_MM_RESTORE();

}

