
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/array.h"
#include "kernel/memory.h"
#include "kernel/object.h"
#include "kernel/fcall.h"
#include "kernel/operators.h"
#include "kernel/file.h"


ZEPHIR_INIT_CLASS(Hachi_App) {

	ZEPHIR_REGISTER_CLASS(Hachi, App, hachi, app, hachi_app_method_entry, 0);

	zend_declare_property_null(hachi_app_ce, SL("conf"), ZEND_ACC_PUBLIC|ZEND_ACC_STATIC TSRMLS_CC);

	return SUCCESS;

}

PHP_METHOD(Hachi_App, init) {

	zephir_nts_static zend_class_entry *_4$$8 = NULL, *_6$$9 = NULL;
	int ZEPHIR_LAST_CALL_STATUS;
	zval *conf_param = NULL, _SERVER, cmd, ret, cgiserver, _0, _2, _3, _1$$3, _5$$9;
	zval conf;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&conf);
	ZVAL_UNDEF(&_SERVER);
	ZVAL_UNDEF(&cmd);
	ZVAL_UNDEF(&ret);
	ZVAL_UNDEF(&cgiserver);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_1$$3);
	ZVAL_UNDEF(&_5$$9);

	ZEPHIR_MM_GROW();
	zephir_get_global(&_SERVER, SL("_SERVER"));
	zephir_fetch_params(1, 1, 0, &conf_param);

	zephir_get_arrval(&conf, conf_param);


	zephir_array_fetch_string(&_0, &_SERVER, SL("argv"), PH_READONLY, "hachi/app.zep", 13 TSRMLS_CC);
	if (zephir_array_isset_long(&_0, 1)) {
		zephir_array_fetch_string(&_1$$3, &_SERVER, SL("argv"), PH_NOISY | PH_READONLY, "hachi/app.zep", 14 TSRMLS_CC);
		ZEPHIR_OBS_VAR(&cmd);
		zephir_array_fetch_long(&cmd, &_1$$3, 1, PH_NOISY, "hachi/app.zep", 14 TSRMLS_CC);
	} else {
		ZEPHIR_INIT_NVAR(&cmd);
		ZVAL_STRING(&cmd, "help");
	}
	zephir_array_fetch_string(&_2, &_SERVER, SL("argv"), PH_NOISY | PH_READONLY, "hachi/app.zep", 18 TSRMLS_CC);
	ZEPHIR_OBS_NVAR(&cmd);
	zephir_array_fetch_long(&cmd, &_2, 1, PH_NOISY, "hachi/app.zep", 18 TSRMLS_CC);
	zephir_update_static_property_ce(hachi_app_ce, SL("conf"), &conf);
	ZEPHIR_INIT_VAR(&_3);
	ZEPHIR_INIT_NVAR(&_3);
	zephir_create_closure_ex(&_3, NULL, hachi_0__closure_ce, SL("__invoke"));
	ZEPHIR_CALL_FUNCTION(NULL, "spl_autoload_register", NULL, 1, &_3);
	zephir_check_call_status();
	do {
		if (ZEPHIR_IS_STRING(&cmd, "stop")) {
			ZEPHIR_CALL_METHOD(&ret, this_ptr, "_stop", NULL, 0);
			zephir_check_call_status();
			if (zephir_is_true(&ret)) {
				php_printf("%s", "stop [OK]!\n");
			} else {
				php_printf("%s", "stop [FAIL]!\n");
			}
			break;
		}
		if (ZEPHIR_IS_STRING(&cmd, "start")) {
			php_printf("%s", "starting...\n");
			ZEPHIR_INIT_VAR(&cgiserver);
			if (!_4$$8) {
			_4$$8 = zephir_fetch_class_str_ex(SL("Cgiserver"), ZEND_FETCH_CLASS_AUTO);
			}
			object_init_ex(&cgiserver, _4$$8);
			if (zephir_has_constructor(&cgiserver TSRMLS_CC)) {
				ZEPHIR_CALL_METHOD(NULL, &cgiserver, "__construct", NULL, 0);
				zephir_check_call_status();
			}
			ZEPHIR_CALL_METHOD(NULL, &cgiserver, "chttpserver", NULL, 0);
			zephir_check_call_status();
			break;
		}
		if (ZEPHIR_IS_STRING(&cmd, "restart")) {
			ZEPHIR_CALL_METHOD(&ret, this_ptr, "_stop", NULL, 0);
			zephir_check_call_status();
			if (zephir_is_true(&ret)) {
				php_printf("%s", "stop [OK]!\n");
			} else {
				php_printf("%s", "stop [FAIL]!\n");
			}
			ZVAL_LONG(&_5$$9, 1);
			ZEPHIR_CALL_FUNCTION(NULL, "sleep", NULL, 2, &_5$$9);
			zephir_check_call_status();
			php_printf("%s", "starting...\n");
			ZEPHIR_INIT_NVAR(&cgiserver);
			if (!_6$$9) {
			_6$$9 = zephir_fetch_class_str_ex(SL("Cgiserver"), ZEND_FETCH_CLASS_AUTO);
			}
			object_init_ex(&cgiserver, _6$$9);
			if (zephir_has_constructor(&cgiserver TSRMLS_CC)) {
				ZEPHIR_CALL_METHOD(NULL, &cgiserver, "__construct", NULL, 0);
				zephir_check_call_status();
			}
			ZEPHIR_CALL_METHOD(NULL, &cgiserver, "chttpserver", NULL, 0);
			zephir_check_call_status();
			break;
		}
		if (ZEPHIR_IS_STRING(&cmd, "status")) {
			ZEPHIR_CALL_METHOD(&ret, this_ptr, "_checkserverisrunning", NULL, 0);
			zephir_check_call_status();
			if (zephir_is_true(&ret)) {
				php_printf("%s", "status [OK]!\n");
			} else {
				php_printf("%s", "status [FAIL]!\n");
			}
			break;
		}
		php_printf("%s", "Usage:php app.php [start | stop | restart | status] \n");
		break;
	} while(0);

	ZEPHIR_MM_RESTORE();

}

PHP_METHOD(Hachi_App, _checkServerIsRunning) {

	zend_bool _2;
	zval pid, res, _0, _1, _3;
	int ZEPHIR_LAST_CALL_STATUS;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&pid);
	ZVAL_UNDEF(&res);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_3);

	ZEPHIR_MM_GROW();

	zephir_read_static_property_ce(&_0, hachi_app_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	zephir_array_fetch_string(&_1, &_0, SL("MASTERHTTPPIDFILE"), PH_NOISY | PH_READONLY, "hachi/app.zep", 107 TSRMLS_CC);
	ZEPHIR_CALL_METHOD(&pid, this_ptr, "_getpidfromfile", NULL, 0, &_1);
	zephir_check_call_status();
	_2 = zephir_is_true(&pid);
	if (_2) {
		ZEPHIR_CALL_METHOD(&_3, this_ptr, "_checkpidisrunning", NULL, 0, &pid);
		zephir_check_call_status();
		_2 = zephir_is_true(&_3);
	}
	ZEPHIR_INIT_VAR(&res);
	ZVAL_BOOL(&res, _2);
	RETURN_CCTOR(res);

}

PHP_METHOD(Hachi_App, _checkPidIsRunning) {

	int ZEPHIR_LAST_CALL_STATUS;
	zval *pid_param = NULL, _0;
	zval pid;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&pid);
	ZVAL_UNDEF(&_0);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &pid_param);

	zephir_get_strval(&pid, pid_param);


	ZVAL_LONG(&_0, 0);
	ZEPHIR_RETURN_CALL_FUNCTION("posix_kill", NULL, 3, &pid, &_0);
	zephir_check_call_status();
	RETURN_MM();

}

PHP_METHOD(Hachi_App, _stop) {

	zval master_id, _0, _1, _2, _3, _8, _9, _10, _11, _12, _4$$3, _5$$3, _6$$4, _7$$4;
	int ZEPHIR_LAST_CALL_STATUS;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&master_id);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_8);
	ZVAL_UNDEF(&_9);
	ZVAL_UNDEF(&_10);
	ZVAL_UNDEF(&_11);
	ZVAL_UNDEF(&_12);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$3);
	ZVAL_UNDEF(&_6$$4);
	ZVAL_UNDEF(&_7$$4);

	ZEPHIR_MM_GROW();

	zephir_read_static_property_ce(&_0, hachi_app_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	zephir_array_fetch_string(&_1, &_0, SL("MASTERHTTPPIDFILE"), PH_NOISY | PH_READONLY, "hachi/app.zep", 122 TSRMLS_CC);
	ZEPHIR_CALL_METHOD(&master_id, this_ptr, "_getpidfromfile", NULL, 0, &_1);
	zephir_check_call_status();
	ZVAL_LONG(&_2, 15);
	ZEPHIR_CALL_FUNCTION(&_3, "posix_kill", NULL, 3, &master_id, &_2);
	zephir_check_call_status();
	if (ZEPHIR_IS_EMPTY(&master_id)) {
		ZEPHIR_INIT_VAR(&_4$$3);
		ZVAL_STRING(&_4$$3, "get master ID failed");
		ZEPHIR_INIT_VAR(&_5$$3);
		ZVAL_STRING(&_5$$3, "ERROR");
		ZEPHIR_CALL_METHOD(NULL, this_ptr, "_log", NULL, 0, &_4$$3, &_5$$3);
		zephir_check_call_status();
		RETURN_MM_BOOL(0);
	} else if (!zephir_is_true(&_3)) {
		ZEPHIR_INIT_VAR(&_6$$4);
		ZVAL_STRING(&_6$$4, "send signal to master failed");
		ZEPHIR_INIT_VAR(&_7$$4);
		ZVAL_STRING(&_7$$4, "ERROR");
		ZEPHIR_CALL_METHOD(NULL, this_ptr, "_log", NULL, 0, &_6$$4, &_7$$4);
		zephir_check_call_status();
		RETURN_MM_BOOL(0);
	}
	zephir_read_static_property_ce(&_2, hachi_app_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	zephir_array_fetch_string(&_8, &_2, SL("MASTERHTTPPIDFILE"), PH_NOISY | PH_READONLY, "hachi/app.zep", 130 TSRMLS_CC);
	ZEPHIR_CALL_FUNCTION(NULL, "unlink", NULL, 4, &_8);
	zephir_check_call_status();
	zephir_read_static_property_ce(&_9, hachi_app_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	zephir_array_fetch_string(&_10, &_9, SL("MANAGERHTTPPIDFILE"), PH_NOISY | PH_READONLY, "hachi/app.zep", 131 TSRMLS_CC);
	ZEPHIR_CALL_FUNCTION(NULL, "unlink", NULL, 4, &_10);
	zephir_check_call_status();
	ZVAL_LONG(&_11, 50000);
	ZEPHIR_CALL_FUNCTION(NULL, "usleep", NULL, 5, &_11);
	zephir_check_call_status();
	ZEPHIR_INIT_VAR(&_12);
	ZVAL_STRING(&_12, "stop [OK]");
	ZEPHIR_CALL_METHOD(NULL, this_ptr, "_log", NULL, 0, &_12);
	zephir_check_call_status();
	RETURN_MM_BOOL(1);

}

PHP_METHOD(Hachi_App, _getPidFromFile) {

	zval *file_dir_param = NULL, pid;
	zval file_dir;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&file_dir);
	ZVAL_UNDEF(&pid);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &file_dir_param);

	zephir_get_strval(&file_dir, file_dir_param);


	ZEPHIR_INIT_VAR(&pid);
	ZVAL_NULL(&pid);
	if ((zephir_file_exists(&file_dir TSRMLS_CC) == SUCCESS)) {
		ZEPHIR_INIT_NVAR(&pid);
		zephir_file_get_contents(&pid, &file_dir TSRMLS_CC);
	}
	RETURN_CCTOR(pid);

}

PHP_METHOD(Hachi_App, _log) {

	int ZEPHIR_LAST_CALL_STATUS;
	zval *msg_param = NULL, *level_param = NULL, date_time, content, _0, _1, _2, _3;
	zval msg, level;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&msg);
	ZVAL_UNDEF(&level);
	ZVAL_UNDEF(&date_time);
	ZVAL_UNDEF(&content);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 1, &msg_param, &level_param);

	zephir_get_strval(&msg, msg_param);
	if (!level_param) {
		ZEPHIR_INIT_VAR(&level);
		ZVAL_STRING(&level, "INFO");
	} else {
		zephir_get_strval(&level, level_param);
	}


	ZEPHIR_INIT_VAR(&_0);
	ZVAL_STRING(&_0, "Y-m-d H:i:s");
	ZEPHIR_CALL_FUNCTION(&date_time, "date", NULL, 6, &_0);
	zephir_check_call_status();
	ZEPHIR_INIT_NVAR(&_0);
	ZVAL_STRING(&_0, "%s#%s#%s\n");
	ZEPHIR_CALL_FUNCTION(&content, "sprintf", NULL, 7, &_0, &date_time, &level, &msg);
	zephir_check_call_status();
	zephir_read_static_property_ce(&_1, hachi_app_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	zephir_array_fetch_string(&_2, &_1, SL("logfile"), PH_NOISY | PH_READONLY, "hachi/app.zep", 156 TSRMLS_CC);
	ZVAL_LONG(&_3, 8);
	ZEPHIR_CALL_FUNCTION(NULL, "file_put_contents", NULL, 8, &_2, &content, &_3);
	zephir_check_call_status();
	ZEPHIR_MM_RESTORE();

}

