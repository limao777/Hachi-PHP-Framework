
extern zend_class_entry *hachi_app_ce;

ZEPHIR_INIT_CLASS(Hachi_App);

PHP_METHOD(Hachi_App, init);
PHP_METHOD(Hachi_App, _checkServerIsRunning);
PHP_METHOD(Hachi_App, _checkPidIsRunning);
PHP_METHOD(Hachi_App, _stop);
PHP_METHOD(Hachi_App, _getPidFromFile);
PHP_METHOD(Hachi_App, _log);

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_app_init, 0, 0, 1)
	ZEND_ARG_ARRAY_INFO(0, conf, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_app__checkpidisrunning, 0, 0, 1)
	ZEND_ARG_INFO(0, pid)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_app__getpidfromfile, 0, 0, 1)
	ZEND_ARG_INFO(0, file_dir)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_app__log, 0, 0, 1)
	ZEND_ARG_INFO(0, msg)
	ZEND_ARG_INFO(0, level)
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(hachi_app_method_entry) {
	PHP_ME(Hachi_App, init, arginfo_hachi_app_init, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_App, _checkServerIsRunning, NULL, ZEND_ACC_PROTECTED)
	PHP_ME(Hachi_App, _checkPidIsRunning, arginfo_hachi_app__checkpidisrunning, ZEND_ACC_PROTECTED)
	PHP_ME(Hachi_App, _stop, NULL, ZEND_ACC_PROTECTED)
	PHP_ME(Hachi_App, _getPidFromFile, arginfo_hachi_app__getpidfromfile, ZEND_ACC_PROTECTED)
	PHP_ME(Hachi_App, _log, arginfo_hachi_app__log, ZEND_ACC_PROTECTED)
	PHP_FE_END
};
