
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/object.h"
#include "kernel/operators.h"
#include "kernel/memory.h"
#include "kernel/fcall.h"
#include "kernel/array.h"
#include "kernel/exception.h"
#include "kernel/exit.h"
#include "kernel/hash.h"
#include "kernel/string.h"
#include "kernel/file.h"


ZEPHIR_INIT_CLASS(Hachi_Ctx) {

	ZEPHIR_REGISTER_CLASS(Hachi, Ctx, hachi, ctx, hachi_ctx_method_entry, 0);

	zend_declare_property_null(hachi_ctx_ce, SL("req"), ZEND_ACC_PUBLIC TSRMLS_CC);

	zend_declare_property_null(hachi_ctx_ce, SL("resp"), ZEND_ACC_PUBLIC TSRMLS_CC);

	zend_declare_property_null(hachi_ctx_ce, SL("quertget"), ZEND_ACC_PUBLIC TSRMLS_CC);

	zend_declare_property_null(hachi_ctx_ce, SL("querypost"), ZEND_ACC_PUBLIC TSRMLS_CC);

	zend_declare_property_null(hachi_ctx_ce, SL("query"), ZEND_ACC_PUBLIC TSRMLS_CC);

	zend_declare_property_null(hachi_ctx_ce, SL("type"), ZEND_ACC_PUBLIC TSRMLS_CC);

	return SUCCESS;

}

PHP_METHOD(Hachi_Ctx, init) {

	zend_bool _1;
	int ZEPHIR_LAST_CALL_STATUS;
	zval routes_conf;
	zval *type_param = NULL, *routes_conf_param = NULL, *request, request_sub, *response, response_sub, _0, ret, f_routes, route_uri, _26, _2$$4, _3$$4, _4$$4, _5$$4, _6$$4, _7$$4, _8$$5, _9$$5, _10$$5, _11$$5, _12$$5, _13$$5, _14$$6, _15$$6, _16$$6, _17$$6, _18$$6, _19$$6, _20$$7, _21$$7, _22$$7, _23$$7, _24$$7, _25$$7, use_controller$$8, _27$$8, _28$$8, _29$$8, _30$$8, _31$$8, _32$$8, _33$$8, _34$$8, _35$$8;
	zval type;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&type);
	ZVAL_UNDEF(&request_sub);
	ZVAL_UNDEF(&response_sub);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&ret);
	ZVAL_UNDEF(&f_routes);
	ZVAL_UNDEF(&route_uri);
	ZVAL_UNDEF(&_26);
	ZVAL_UNDEF(&_2$$4);
	ZVAL_UNDEF(&_3$$4);
	ZVAL_UNDEF(&_4$$4);
	ZVAL_UNDEF(&_5$$4);
	ZVAL_UNDEF(&_6$$4);
	ZVAL_UNDEF(&_7$$4);
	ZVAL_UNDEF(&_8$$5);
	ZVAL_UNDEF(&_9$$5);
	ZVAL_UNDEF(&_10$$5);
	ZVAL_UNDEF(&_11$$5);
	ZVAL_UNDEF(&_12$$5);
	ZVAL_UNDEF(&_13$$5);
	ZVAL_UNDEF(&_14$$6);
	ZVAL_UNDEF(&_15$$6);
	ZVAL_UNDEF(&_16$$6);
	ZVAL_UNDEF(&_17$$6);
	ZVAL_UNDEF(&_18$$6);
	ZVAL_UNDEF(&_19$$6);
	ZVAL_UNDEF(&_20$$7);
	ZVAL_UNDEF(&_21$$7);
	ZVAL_UNDEF(&_22$$7);
	ZVAL_UNDEF(&_23$$7);
	ZVAL_UNDEF(&_24$$7);
	ZVAL_UNDEF(&_25$$7);
	ZVAL_UNDEF(&use_controller$$8);
	ZVAL_UNDEF(&_27$$8);
	ZVAL_UNDEF(&_28$$8);
	ZVAL_UNDEF(&_29$$8);
	ZVAL_UNDEF(&_30$$8);
	ZVAL_UNDEF(&_31$$8);
	ZVAL_UNDEF(&_32$$8);
	ZVAL_UNDEF(&_33$$8);
	ZVAL_UNDEF(&_34$$8);
	ZVAL_UNDEF(&_35$$8);
	ZVAL_UNDEF(&routes_conf);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 4, 0, &type_param, &routes_conf_param, &request, &response);

	zephir_get_strval(&type, type_param);
	zephir_get_arrval(&routes_conf, routes_conf_param);


	zephir_update_property_zval(this_ptr, SL("type"), &type);
	zephir_read_property(&_0, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	if (ZEPHIR_IS_STRING(&_0, "C")) {
		zephir_update_property_zval(this_ptr, SL("req"), request);
		zephir_update_property_zval(this_ptr, SL("resp"), response);
	}
	ZEPHIR_INIT_VAR(&f_routes);
	object_init_ex(&f_routes, hachi_routes_ce);
	if (zephir_has_constructor(&f_routes TSRMLS_CC)) {
		ZEPHIR_CALL_METHOD(NULL, &f_routes, "__construct", NULL, 0);
		zephir_check_call_status();
	}
	_1 = zephir_isset_property(request, SL("get"));
	if (_1) {
		_1 = zephir_isset_property(request, SL("post"));
	}
	if (_1) {
		zephir_read_property(&_2$$4, request, SL("server"), PH_NOISY_CC | PH_READONLY);
		zephir_array_fetch_string(&_3$$4, &_2$$4, SL("request_uri"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 25 TSRMLS_CC);
		zephir_array_fetch_string(&_4$$4, &routes_conf, SL("group"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 25 TSRMLS_CC);
		zephir_array_fetch_string(&_5$$4, &routes_conf, SL("re_method"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 25 TSRMLS_CC);
		zephir_read_property(&_6$$4, request, SL("get"), PH_NOISY_CC | PH_READONLY);
		zephir_read_property(&_7$$4, request, SL("post"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_CALL_METHOD(&route_uri, &f_routes, "uripraser", NULL, 9, &_3$$4, &_4$$4, &_5$$4, &_6$$4, &_7$$4);
		zephir_check_call_status();
	} else if (zephir_isset_property(request, SL("get"))) {
		zephir_read_property(&_8$$5, request, SL("server"), PH_NOISY_CC | PH_READONLY);
		zephir_array_fetch_string(&_9$$5, &_8$$5, SL("request_uri"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 27 TSRMLS_CC);
		zephir_array_fetch_string(&_10$$5, &routes_conf, SL("group"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 27 TSRMLS_CC);
		zephir_array_fetch_string(&_11$$5, &routes_conf, SL("re_method"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 27 TSRMLS_CC);
		zephir_read_property(&_12$$5, request, SL("get"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_INIT_VAR(&_13$$5);
		array_init(&_13$$5);
		ZEPHIR_CALL_METHOD(&route_uri, &f_routes, "uripraser", NULL, 9, &_9$$5, &_10$$5, &_11$$5, &_12$$5, &_13$$5);
		zephir_check_call_status();
	} else if (zephir_isset_property(request, SL("post"))) {
		zephir_read_property(&_14$$6, request, SL("server"), PH_NOISY_CC | PH_READONLY);
		zephir_array_fetch_string(&_15$$6, &_14$$6, SL("request_uri"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 29 TSRMLS_CC);
		zephir_array_fetch_string(&_16$$6, &routes_conf, SL("group"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 29 TSRMLS_CC);
		zephir_array_fetch_string(&_17$$6, &routes_conf, SL("re_method"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 29 TSRMLS_CC);
		ZEPHIR_INIT_VAR(&_18$$6);
		array_init(&_18$$6);
		zephir_read_property(&_19$$6, request, SL("post"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_CALL_METHOD(&route_uri, &f_routes, "uripraser", NULL, 9, &_15$$6, &_16$$6, &_17$$6, &_18$$6, &_19$$6);
		zephir_check_call_status();
	} else {
		zephir_read_property(&_20$$7, request, SL("server"), PH_NOISY_CC | PH_READONLY);
		zephir_array_fetch_string(&_21$$7, &_20$$7, SL("request_uri"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 31 TSRMLS_CC);
		zephir_array_fetch_string(&_22$$7, &routes_conf, SL("group"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 31 TSRMLS_CC);
		zephir_array_fetch_string(&_23$$7, &routes_conf, SL("re_method"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 31 TSRMLS_CC);
		ZEPHIR_INIT_VAR(&_24$$7);
		array_init(&_24$$7);
		ZEPHIR_INIT_VAR(&_25$$7);
		array_init(&_25$$7);
		ZEPHIR_CALL_METHOD(&route_uri, &f_routes, "uripraser", NULL, 9, &_21$$7, &_22$$7, &_23$$7, &_24$$7, &_25$$7);
		zephir_check_call_status();
	}
	ZEPHIR_INIT_NVAR(&f_routes);
	ZVAL_NULL(&f_routes);
	zephir_array_fetch_string(&_26, &route_uri, SL("code"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 36 TSRMLS_CC);
	ZEPHIR_INIT_VAR(&ret);
	if (ZEPHIR_IS_LONG_IDENTICAL(&_26, 0)) {
		zephir_array_fetch_string(&_27$$8, &route_uri, SL("controller"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 38 TSRMLS_CC);
		ZEPHIR_INIT_VAR(&_28$$8);
		ZVAL_STRING(&_28$$8, "Controllers_%s");
		ZEPHIR_CALL_FUNCTION(&use_controller$$8, "sprintf", NULL, 7, &_28$$8, &_27$$8);
		zephir_check_call_status();
		zephir_array_fetch_string(&_29$$8, &route_uri, SL("params"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 39 TSRMLS_CC);
		zephir_array_fetch_string(&_30$$8, &_29$$8, SL("get"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 39 TSRMLS_CC);
		zephir_update_property_zval(this_ptr, SL("queryget"), &_30$$8);
		zephir_array_fetch_string(&_31$$8, &route_uri, SL("params"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 40 TSRMLS_CC);
		zephir_array_fetch_string(&_32$$8, &_31$$8, SL("post"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 40 TSRMLS_CC);
		zephir_update_property_zval(this_ptr, SL("querypost"), &_32$$8);
		zephir_array_fetch_string(&_33$$8, &route_uri, SL("params"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 41 TSRMLS_CC);
		zephir_array_fetch_string(&_34$$8, &_33$$8, SL("query"), PH_NOISY | PH_READONLY, "hachi/ctx.zep", 41 TSRMLS_CC);
		zephir_update_property_zval(this_ptr, SL("query"), &_34$$8);
		zephir_create_array(&ret, 3, 0 TSRMLS_CC);
		add_assoc_long_ex(&ret, SL("code"), 0);
		zephir_array_update_string(&ret, SL("controller"), &use_controller$$8, PH_COPY | PH_SEPARATE);
		ZEPHIR_OBS_VAR(&_35$$8);
		zephir_array_fetch_string(&_35$$8, &route_uri, SL("action"), PH_NOISY, "hachi/ctx.zep", 42 TSRMLS_CC);
		zephir_array_update_string(&ret, SL("action"), &_35$$8, PH_COPY | PH_SEPARATE);
		RETURN_CCTOR(ret);
	} else {
		zephir_create_array(&ret, 1, 0 TSRMLS_CC);
		add_assoc_long_ex(&ret, SL("code"), 500);
		RETURN_CCTOR(ret);
	}
	zephir_create_array(return_value, 1, 0 TSRMLS_CC);
	add_assoc_long_ex(return_value, SL("code"), -1);
	RETURN_MM();

}

PHP_METHOD(Hachi_Ctx, getQuery) {

	ZEPHIR_INIT_THIS();


	RETURN_MEMBER(this_ptr, "query");

}

PHP_METHOD(Hachi_Ctx, setCookie) {

	int ZEPHIR_LAST_CALL_STATUS;
	zend_bool secure, httponly;
	long expire;
	zval *key_param = NULL, *value_param = NULL, *expire_param = NULL, *path_param = NULL, *domain_param = NULL, *secure_param = NULL, *httponly_param = NULL, _0, _1, _2$$3, _3$$3, _4$$3, _5$$3, _6$$4, _7$$4, _8$$4;
	zval key, value, path, domain;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&key);
	ZVAL_UNDEF(&value);
	ZVAL_UNDEF(&path);
	ZVAL_UNDEF(&domain);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$3);
	ZVAL_UNDEF(&_6$$4);
	ZVAL_UNDEF(&_7$$4);
	ZVAL_UNDEF(&_8$$4);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 6, &key_param, &value_param, &expire_param, &path_param, &domain_param, &secure_param, &httponly_param);

	zephir_get_strval(&key, key_param);
	if (!value_param) {
		ZEPHIR_INIT_VAR(&value);
		ZVAL_STRING(&value, "");
	} else {
		zephir_get_strval(&value, value_param);
	}
	if (!expire_param) {
		expire = 0;
	} else {
		expire = zephir_get_intval(expire_param);
	}
	if (!path_param) {
		ZEPHIR_INIT_VAR(&path);
		ZVAL_STRING(&path, "/");
	} else {
		zephir_get_strval(&path, path_param);
	}
	if (!domain_param) {
		ZEPHIR_INIT_VAR(&domain);
		ZVAL_STRING(&domain, "");
	} else {
		zephir_get_strval(&domain, domain_param);
	}
	if (!secure_param) {
		secure = 0;
	} else {
		secure = zephir_get_boolval(secure_param);
	}
	if (!httponly_param) {
		httponly = 0;
	} else {
		httponly = zephir_get_boolval(httponly_param);
	}


	zephir_read_property(&_0, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	zephir_read_property(&_1, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	if (ZEPHIR_IS_STRING(&_0, "C")) {
		zephir_read_property(&_2$$3, this_ptr, SL("resp"), PH_NOISY_CC | PH_READONLY);
		ZVAL_LONG(&_3$$3, expire);
		if (secure) {
			ZVAL_BOOL(&_4$$3, 1);
		} else {
			ZVAL_BOOL(&_4$$3, 0);
		}
		if (httponly) {
			ZVAL_BOOL(&_5$$3, 1);
		} else {
			ZVAL_BOOL(&_5$$3, 0);
		}
		ZEPHIR_CALL_METHOD(NULL, &_2$$3, "cookie", NULL, 0, &key, &value, &_3$$3, &path, &domain, &_4$$3, &_5$$3);
		zephir_check_call_status();
	} else if (ZEPHIR_IS_STRING(&_1, "F")) {
		ZVAL_LONG(&_6$$4, expire);
		ZVAL_BOOL(&_7$$4, (secure ? 1 : 0));
		ZVAL_BOOL(&_8$$4, (httponly ? 1 : 0));
		ZEPHIR_CALL_FUNCTION(NULL, "setcookie", NULL, 10, &key, &value, &_6$$4, &path, &domain, &_7$$4, &_8$$4);
		zephir_check_call_status();
	}
	RETURN_MM_LONG(1);

}

PHP_METHOD(Hachi_Ctx, getCookie) {

	zval *key_param = NULL, _COOKIE, ret, _0, _1, _2$$3, _3$$3, _4$$3, _5$$4, _6$$4, _7$$5;
	zval key;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&key);
	ZVAL_UNDEF(&_COOKIE);
	ZVAL_UNDEF(&ret);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$4);
	ZVAL_UNDEF(&_6$$4);
	ZVAL_UNDEF(&_7$$5);

	ZEPHIR_MM_GROW();
	zephir_get_global(&_COOKIE, SL("_COOKIE"));
	zephir_fetch_params(1, 1, 0, &key_param);

	zephir_get_strval(&key, key_param);


	zephir_read_property(&_0, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	zephir_read_property(&_1, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	if (ZEPHIR_IS_STRING(&_0, "C")) {
		zephir_read_property(&_2$$3, this_ptr, SL("req"), PH_NOISY_CC | PH_READONLY);
		zephir_read_property(&_3$$3, &_2$$3, SL("cookie"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_OBS_VAR(&_4$$3);
		zephir_array_fetch(&_4$$3, &_3$$3, &key, PH_NOISY, "hachi/ctx.zep", 74 TSRMLS_CC);
		if (!(ZEPHIR_IS_EMPTY(&_4$$3))) {
			zephir_read_property(&_5$$4, this_ptr, SL("req"), PH_NOISY_CC | PH_READONLY);
			zephir_read_property(&_6$$4, &_5$$4, SL("cookie"), PH_NOISY_CC | PH_READONLY);
			zephir_array_fetch(&ret, &_6$$4, &key, PH_NOISY | PH_READONLY, "hachi/ctx.zep", 75 TSRMLS_CC);
		}
	} else if (ZEPHIR_IS_STRING(&_1, "F")) {
		ZEPHIR_OBS_VAR(&_7$$5);
		zephir_array_fetch(&_7$$5, &_COOKIE, &key, PH_NOISY, "hachi/ctx.zep", 79 TSRMLS_CC);
		if (!(ZEPHIR_IS_EMPTY(&_7$$5))) {
			ZEPHIR_OBS_VAR(&ret);
			zephir_array_fetch(&ret, &_COOKIE, &key, PH_NOISY, "hachi/ctx.zep", 80 TSRMLS_CC);
		}
	}
	RETURN_CTOR(ret);

}

PHP_METHOD(Hachi_Ctx, redirect) {

	int status_code, ZEPHIR_LAST_CALL_STATUS;
	zval *uri_param = NULL, *status_code_param = NULL, __$true, _0, _1, _2$$3, _3$$3, _4$$3, _5$$3, _6$$4, _7$$4, _8$$4;
	zval uri;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&uri);
	ZVAL_BOOL(&__$true, 1);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$3);
	ZVAL_UNDEF(&_6$$4);
	ZVAL_UNDEF(&_7$$4);
	ZVAL_UNDEF(&_8$$4);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 1, &uri_param, &status_code_param);

	zephir_get_strval(&uri, uri_param);
	if (!status_code_param) {
		status_code = 302;
	} else {
		status_code = zephir_get_intval(status_code_param);
	}


	zephir_read_property(&_0, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	zephir_read_property(&_1, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	if (ZEPHIR_IS_STRING(&_0, "C")) {
		zephir_read_property(&_2$$3, this_ptr, SL("resp"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_INIT_VAR(&_3$$3);
		ZVAL_STRING(&_3$$3, "Location");
		ZEPHIR_CALL_METHOD(NULL, &_2$$3, "header", NULL, 0, &_3$$3, &uri);
		zephir_check_call_status();
		zephir_read_property(&_4$$3, this_ptr, SL("resp"), PH_NOISY_CC | PH_READONLY);
		ZVAL_LONG(&_5$$3, status_code);
		ZEPHIR_CALL_METHOD(NULL, &_4$$3, "status", NULL, 0, &_5$$3);
		zephir_check_call_status();
		ZEPHIR_THROW_EXCEPTION_DEBUG_STR(zend_exception_get_default(TSRMLS_C), "redirect", "hachi/ctx.zep", 92);
		return;
	} else if (ZEPHIR_IS_STRING(&_1, "F")) {
		ZEPHIR_INIT_VAR(&_6$$4);
		ZVAL_STRING(&_6$$4, "Location: %s");
		ZEPHIR_CALL_FUNCTION(&_7$$4, "sprintf", NULL, 7, &_6$$4, &uri);
		zephir_check_call_status();
		ZVAL_LONG(&_8$$4, status_code);
		ZEPHIR_CALL_FUNCTION(NULL, "header", NULL, 11, &_7$$4, &__$true, &_8$$4);
		zephir_check_call_status();
	}
	RETURN_MM_LONG(0);

}

PHP_METHOD(Hachi_Ctx, end) {

	int ZEPHIR_LAST_CALL_STATUS;
	zval *message_param = NULL, _0, _1, _2$$3;
	zval message;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&message);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2$$3);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 0, 1, &message_param);

	if (!message_param) {
		ZEPHIR_INIT_VAR(&message);
		ZVAL_STRING(&message, "NULL");
	} else {
		zephir_get_strval(&message, message_param);
	}


	zephir_read_property(&_0, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	zephir_read_property(&_1, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	if (ZEPHIR_IS_STRING(&_0, "C")) {
		ZEPHIR_INIT_VAR(&_2$$3);
		object_init_ex(&_2$$3, zend_exception_get_default(TSRMLS_C));
		ZEPHIR_CALL_METHOD(NULL, &_2$$3, "__construct", NULL, 12, &message);
		zephir_check_call_status();
		zephir_throw_exception_debug(&_2$$3, "hachi/ctx.zep", 105 TSRMLS_CC);
		ZEPHIR_MM_RESTORE();
		return;
	} else if (ZEPHIR_IS_STRING(&_1, "F")) {
		zend_print_zval(&message, 0);
		ZEPHIR_MM_RESTORE();
		zephir_exit_empty();
	}
	RETURN_MM_LONG(0);

}

PHP_METHOD(Hachi_Ctx, getHeader) {

	zend_string *_6$$4;
	zend_ulong _5$$4;
	zval func_header$$4;
	int ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_10 = NULL, *_15 = NULL;
	zval _SERVER, _0, _1, _2$$3, _3$$3, p$$4, v$$4, temp$$4, *_4$$4, _7$$5, _8$$5, _9$$6, _11$$6, _12$$6, _13$$6, _14$$6;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&_SERVER);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&p$$4);
	ZVAL_UNDEF(&v$$4);
	ZVAL_UNDEF(&temp$$4);
	ZVAL_UNDEF(&_7$$5);
	ZVAL_UNDEF(&_8$$5);
	ZVAL_UNDEF(&_9$$6);
	ZVAL_UNDEF(&_11$$6);
	ZVAL_UNDEF(&_12$$6);
	ZVAL_UNDEF(&_13$$6);
	ZVAL_UNDEF(&_14$$6);
	ZVAL_UNDEF(&func_header$$4);

	ZEPHIR_MM_GROW();
	zephir_get_global(&_SERVER, SL("_SERVER"));

	zephir_read_property(&_0, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	zephir_read_property(&_1, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	if (ZEPHIR_IS_STRING(&_0, "C")) {
		zephir_read_property(&_2$$3, this_ptr, SL("req"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_OBS_VAR(&_3$$3);
		zephir_read_property(&_3$$3, &_2$$3, SL("header"), PH_NOISY_CC);
		RETURN_CCTOR(_3$$3);
	} else if (ZEPHIR_IS_STRING(&_1, "F")) {
		zephir_is_iterable(&_SERVER, 0, "hachi/ctx.zep", 133);
		ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&_SERVER), _5$$4, _6$$4, _4$$4)
		{
			ZEPHIR_INIT_NVAR(&p$$4);
			if (_6$$4 != NULL) { 
				ZVAL_STR_COPY(&p$$4, _6$$4);
			} else {
				ZVAL_LONG(&p$$4, _5$$4);
			}
			ZEPHIR_INIT_NVAR(&v$$4);
			ZVAL_COPY(&v$$4, _4$$4);
			ZEPHIR_INIT_NVAR(&_7$$5);
			ZVAL_STRING(&_7$$5, "HTTP_");
			ZEPHIR_INIT_NVAR(&_8$$5);
			zephir_fast_strpos(&_8$$5, &p$$4, &_7$$5, 0 );
			if (ZEPHIR_IS_LONG_IDENTICAL(&_8$$5, 0)) {
				ZVAL_LONG(&_9$$6, 5);
				ZEPHIR_CALL_FUNCTION(&temp$$4, "mb_substr", &_10, 13, &p$$4, &_9$$6);
				zephir_check_call_status();
				ZEPHIR_INIT_NVAR(&_11$$6);
				ZEPHIR_INIT_NVAR(&_12$$6);
				ZVAL_STRING(&_12$$6, "_");
				ZEPHIR_INIT_NVAR(&_13$$6);
				ZVAL_STRING(&_13$$6, "-");
				zephir_fast_str_replace(&_11$$6, &_12$$6, &_13$$6, &temp$$4 TSRMLS_CC);
				ZEPHIR_CPY_WRT(&temp$$4, &_11$$6);
				ZEPHIR_CALL_METHOD(&_14$$6, &temp$$4, "lower", &_15, 0);
				zephir_check_call_status();
				ZEPHIR_CPY_WRT(&temp$$4, &_14$$6);
				ZEPHIR_CPY_WRT(&func_header$$4, &v$$4);
			}
		} ZEND_HASH_FOREACH_END();
		ZEPHIR_INIT_NVAR(&v$$4);
		ZEPHIR_INIT_NVAR(&p$$4);
		RETURN_CTOR(func_header$$4);
	}
	array_init(return_value);
	RETURN_MM();

}

PHP_METHOD(Hachi_Ctx, setHeader) {

	int ZEPHIR_LAST_CALL_STATUS;
	zval *key_param = NULL, *value_param = NULL, _0, _1, _2$$3, _3$$4, _4$$4;
	zval key, value;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&key);
	ZVAL_UNDEF(&value);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$4);
	ZVAL_UNDEF(&_4$$4);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 2, 0, &key_param, &value_param);

	zephir_get_strval(&key, key_param);
	zephir_get_strval(&value, value_param);


	zephir_read_property(&_0, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	zephir_read_property(&_1, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	if (ZEPHIR_IS_STRING(&_0, "C")) {
		zephir_read_property(&_2$$3, this_ptr, SL("resp"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_CALL_METHOD(NULL, &_2$$3, "header", NULL, 0, &key, &value);
		zephir_check_call_status();
	} else if (ZEPHIR_IS_STRING(&_1, "F")) {
		ZEPHIR_INIT_VAR(&_3$$4);
		ZVAL_STRING(&_3$$4, "%s: %s");
		ZEPHIR_CALL_FUNCTION(&_4$$4, "sprintf", NULL, 7, &_3$$4, &key, &value);
		zephir_check_call_status();
		ZEPHIR_CALL_FUNCTION(NULL, "header", NULL, 11, &_4$$4);
		zephir_check_call_status();
	}
	RETURN_MM_LONG(1);

}

PHP_METHOD(Hachi_Ctx, getRawContent) {

	zval ret, _0, _1, _2$$3, _3$$4;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&ret);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$4);

	ZEPHIR_MM_GROW();

	ZEPHIR_INIT_VAR(&ret);
	ZVAL_NULL(&ret);
	zephir_read_property(&_0, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	zephir_read_property(&_1, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	if (ZEPHIR_IS_STRING(&_0, "C")) {
		zephir_read_property(&_2$$3, this_ptr, SL("req"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_OBS_NVAR(&ret);
		zephir_read_property(&ret, &_2$$3, SL("rawContent"), PH_NOISY_CC);
	} else if (ZEPHIR_IS_STRING(&_1, "F")) {
		ZEPHIR_INIT_VAR(&_3$$4);
		ZVAL_STRING(&_3$$4, "php://input");
		ZEPHIR_INIT_NVAR(&ret);
		zephir_file_get_contents(&ret, &_3$$4 TSRMLS_CC);
	}
	RETURN_CCTOR(ret);

}

PHP_METHOD(Hachi_Ctx, getFiles) {

	zval _FILES, ret, _0, _1, _2$$3;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&_FILES);
	ZVAL_UNDEF(&ret);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2$$3);

	ZEPHIR_MM_GROW();
	zephir_get_global(&_FILES, SL("_FILES"));

	ZEPHIR_INIT_VAR(&ret);
	ZVAL_NULL(&ret);
	zephir_read_property(&_0, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	zephir_read_property(&_1, this_ptr, SL("type"), PH_NOISY_CC | PH_READONLY);
	if (ZEPHIR_IS_STRING(&_0, "C")) {
		zephir_read_property(&_2$$3, this_ptr, SL("req"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_OBS_NVAR(&ret);
		zephir_read_property(&ret, &_2$$3, SL("files"), PH_NOISY_CC);
	} else if (ZEPHIR_IS_STRING(&_1, "F")) {
		ZEPHIR_CPY_WRT(&ret, &_FILES);
	}
	RETURN_CCTOR(ret);

}

