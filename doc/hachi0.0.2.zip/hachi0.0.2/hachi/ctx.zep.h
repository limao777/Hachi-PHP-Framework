
extern zend_class_entry *hachi_ctx_ce;

ZEPHIR_INIT_CLASS(Hachi_Ctx);

PHP_METHOD(Hachi_Ctx, initCGI);
PHP_METHOD(Hachi_Ctx, initFPM);
PHP_METHOD(Hachi_Ctx, getQuery);
PHP_METHOD(Hachi_Ctx, setCookie);
PHP_METHOD(Hachi_Ctx, getCookie);
PHP_METHOD(Hachi_Ctx, redirect);
PHP_METHOD(Hachi_Ctx, end);
PHP_METHOD(Hachi_Ctx, getHeader);
PHP_METHOD(Hachi_Ctx, setHeader);
PHP_METHOD(Hachi_Ctx, getRawContent);
PHP_METHOD(Hachi_Ctx, getFiles);

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_ctx_initcgi, 0, 0, 3)
	ZEND_ARG_ARRAY_INFO(0, routes_conf, 0)
	ZEND_ARG_INFO(0, request)
	ZEND_ARG_INFO(0, response)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_ctx_initfpm, 0, 0, 2)
	ZEND_ARG_ARRAY_INFO(0, routes_conf, 0)
	ZEND_ARG_INFO(0, request_uri)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_ctx_setcookie, 0, 0, 1)
	ZEND_ARG_INFO(0, key)
	ZEND_ARG_INFO(0, value)
	ZEND_ARG_INFO(0, expire)
	ZEND_ARG_INFO(0, path)
	ZEND_ARG_INFO(0, domain)
	ZEND_ARG_INFO(0, secure)
	ZEND_ARG_INFO(0, httponly)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_ctx_getcookie, 0, 0, 1)
	ZEND_ARG_INFO(0, key)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_ctx_redirect, 0, 0, 1)
	ZEND_ARG_INFO(0, uri)
	ZEND_ARG_INFO(0, status_code)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_ctx_end, 0, 0, 0)
	ZEND_ARG_INFO(0, message)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_ctx_setheader, 0, 0, 2)
	ZEND_ARG_INFO(0, key)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(hachi_ctx_method_entry) {
	PHP_ME(Hachi_Ctx, initCGI, arginfo_hachi_ctx_initcgi, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Ctx, initFPM, arginfo_hachi_ctx_initfpm, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Ctx, getQuery, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Ctx, setCookie, arginfo_hachi_ctx_setcookie, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Ctx, getCookie, arginfo_hachi_ctx_getcookie, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Ctx, redirect, arginfo_hachi_ctx_redirect, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Ctx, end, arginfo_hachi_ctx_end, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Ctx, getHeader, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Ctx, setHeader, arginfo_hachi_ctx_setheader, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Ctx, getRawContent, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Ctx, getFiles, NULL, ZEND_ACC_PUBLIC)
	PHP_FE_END
};
