
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/object.h"
#include "kernel/memory.h"
#include "kernel/string.h"
#include "kernel/operators.h"
#include "kernel/fcall.h"
#include "kernel/hash.h"
#include "kernel/array.h"


ZEPHIR_INIT_CLASS(Hachi_Routes) {

	ZEPHIR_REGISTER_CLASS(Hachi, Routes, hachi, routes, hachi_routes_method_entry, 0);

	zend_declare_property_null(hachi_routes_ce, SL("include_method_array"), ZEND_ACC_PRIVATE TSRMLS_CC);

	zend_declare_property_null(hachi_routes_ce, SL("route_group"), ZEND_ACC_PRIVATE TSRMLS_CC);

	return SUCCESS;

}

PHP_METHOD(Hachi_Routes, uriPraser) {

	zend_bool _20$$9, _21$$10, _24$$11;
	zend_string *_13;
	zend_ulong _12;
	int ZEPHIR_LAST_CALL_STATUS, uri_counter = 0, code = 0, i = 0, _22$$10;
	zephir_fcall_cache_entry *_6 = NULL, *_15 = NULL;
	zval route_group, method_arr, param_get, param_post, params, ret, _33;
	zval *uri_param = NULL, *route_group_param = NULL, *method_arr_param = NULL, *param_get_param = NULL, *param_post_param = NULL, group, controller, action, uri_array, p, v, uri_array_length, _0, _1, _7, _8, _9, _10, *_11, _27, _28, _29, _30, _31, _32, _2$$3, _3$$3, _4$$3, _5$$3, _14$$4, _16$$5, _17$$5, _18$$5, _19$$5, _23$$10, _25$$12, _26$$12;
	zval uri, pattern;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&uri);
	ZVAL_UNDEF(&pattern);
	ZVAL_UNDEF(&group);
	ZVAL_UNDEF(&controller);
	ZVAL_UNDEF(&action);
	ZVAL_UNDEF(&uri_array);
	ZVAL_UNDEF(&p);
	ZVAL_UNDEF(&v);
	ZVAL_UNDEF(&uri_array_length);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_7);
	ZVAL_UNDEF(&_8);
	ZVAL_UNDEF(&_9);
	ZVAL_UNDEF(&_10);
	ZVAL_UNDEF(&_27);
	ZVAL_UNDEF(&_28);
	ZVAL_UNDEF(&_29);
	ZVAL_UNDEF(&_30);
	ZVAL_UNDEF(&_31);
	ZVAL_UNDEF(&_32);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$3);
	ZVAL_UNDEF(&_14$$4);
	ZVAL_UNDEF(&_16$$5);
	ZVAL_UNDEF(&_17$$5);
	ZVAL_UNDEF(&_18$$5);
	ZVAL_UNDEF(&_19$$5);
	ZVAL_UNDEF(&_23$$10);
	ZVAL_UNDEF(&_25$$12);
	ZVAL_UNDEF(&_26$$12);
	ZVAL_UNDEF(&route_group);
	ZVAL_UNDEF(&method_arr);
	ZVAL_UNDEF(&param_get);
	ZVAL_UNDEF(&param_post);
	ZVAL_UNDEF(&params);
	ZVAL_UNDEF(&ret);
	ZVAL_UNDEF(&_33);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 5, 0, &uri_param, &route_group_param, &method_arr_param, &param_get_param, &param_post_param);

	zephir_get_strval(&uri, uri_param);
	zephir_get_arrval(&route_group, route_group_param);
	zephir_get_arrval(&method_arr, method_arr_param);
	zephir_get_arrval(&param_get, param_get_param);
	zephir_get_arrval(&param_post, param_post_param);


	zephir_update_property_zval(this_ptr, SL("include_method_array"), &method_arr);
	zephir_update_property_zval(this_ptr, SL("route_group"), &route_group);
	uri_counter = 0;
	code = 0;
	ZEPHIR_INIT_VAR(&group);
	ZVAL_NULL(&group);
	ZEPHIR_INIT_VAR(&controller);
	ZVAL_NULL(&controller);
	ZEPHIR_INIT_VAR(&action);
	ZVAL_NULL(&action);
	ZEPHIR_INIT_VAR(&params);
	array_init(&params);
	ZEPHIR_INIT_VAR(&_0);
	ZVAL_STRING(&_0, "?");
	ZEPHIR_INIT_VAR(&_1);
	zephir_fast_strpos(&_1, &uri, &_0, 0 );
	if (ZEPHIR_GT_LONG(&_1, 0)) {
		ZEPHIR_INIT_VAR(&_2$$3);
		ZVAL_STRING(&_2$$3, "?");
		ZEPHIR_INIT_VAR(&_3$$3);
		zephir_fast_strpos(&_3$$3, &uri, &_2$$3, 0 );
		ZVAL_LONG(&_4$$3, 0);
		ZEPHIR_CALL_FUNCTION(&_5$$3, "mb_substr", &_6, 13, &uri, &_4$$3, &_3$$3);
		zephir_check_call_status();
		zephir_get_strval(&uri, &_5$$3);
	}
	ZEPHIR_CALL_METHOD(&_7, this_ptr, "__dealroutemethod", NULL, 14, &uri);
	zephir_check_call_status();
	zephir_get_strval(&uri, &_7);
	ZEPHIR_INIT_VAR(&_8);
	ZEPHIR_INIT_VAR(&_9);
	ZVAL_STRING(&_9, "/");
	zephir_fast_trim(&_8, &uri, &_9, ZEPHIR_TRIM_LEFT TSRMLS_CC);
	zephir_get_strval(&uri, &_8);
	zephir_read_property(&_10, this_ptr, SL("route_group"), PH_NOISY_CC | PH_READONLY);
	zephir_is_iterable(&_10, 0, "hachi/routes.zep", 56);
	ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&_10), _12, _13, _11)
	{
		ZEPHIR_INIT_NVAR(&p);
		if (_13 != NULL) { 
			ZVAL_STR_COPY(&p, _13);
		} else {
			ZVAL_LONG(&p, _12);
		}
		ZEPHIR_INIT_NVAR(&v);
		ZVAL_COPY(&v, _11);
		ZEPHIR_CALL_FUNCTION(&_14$$4, "stripos", &_15, 15, &uri, &p);
		zephir_check_call_status();
		if (ZEPHIR_IS_LONG_IDENTICAL(&_14$$4, 0)) {
			ZEPHIR_CPY_WRT(&group, &v);
			ZVAL_LONG(&_16$$5, zephir_fast_strlen_ev(&p));
			ZEPHIR_CALL_FUNCTION(&_17$$5, "mb_substr", &_6, 13, &uri, &_16$$5);
			zephir_check_call_status();
			zephir_get_strval(&uri, &_17$$5);
			ZEPHIR_INIT_NVAR(&_18$$5);
			ZEPHIR_INIT_NVAR(&_19$$5);
			ZVAL_STRING(&_19$$5, "/");
			zephir_fast_trim(&_18$$5, &uri, &_19$$5, ZEPHIR_TRIM_LEFT TSRMLS_CC);
			zephir_get_strval(&uri, &_18$$5);
		}
	} ZEND_HASH_FOREACH_END();
	ZEPHIR_INIT_NVAR(&v);
	ZEPHIR_INIT_NVAR(&p);
	ZEPHIR_INIT_VAR(&uri_array);
	zephir_fast_explode_str(&uri_array, SL("/"), &uri, LONG_MAX TSRMLS_CC);
	if (zephir_array_isset_long(&uri_array, uri_counter)) {
		ZEPHIR_OBS_NVAR(&controller);
		zephir_array_fetch_long(&controller, &uri_array, uri_counter, PH_NOISY, "hachi/routes.zep", 59 TSRMLS_CC);
	} else {
		ZEPHIR_INIT_NVAR(&controller);
		ZVAL_STRING(&controller, "welcome");
	}
	if (ZEPHIR_IS_EMPTY(&controller)) {
		ZEPHIR_INIT_NVAR(&controller);
		ZVAL_STRING(&controller, "welcome");
	}
	if (zephir_array_isset_long(&uri_array, (uri_counter + 1))) {
		ZEPHIR_OBS_NVAR(&action);
		zephir_array_fetch_long(&action, &uri_array, (uri_counter + 1), PH_NOISY, "hachi/routes.zep", 68 TSRMLS_CC);
		ZEPHIR_INIT_VAR(&uri_array_length);
		ZVAL_LONG(&uri_array_length, zephir_fast_count_int(&uri_array TSRMLS_CC));
		_20$$9 = ZEPHIR_GT_LONG(&uri_array_length, ((uri_counter + 2)));
		if (_20$$9) {
			_20$$9 = ZEPHIR_LT_LONG(&uri_array_length, 101);
		}
		if (_20$$9) {
			ZEPHIR_CPY_WRT(&_23$$10, &uri_array_length);
			_22$$10 = (uri_counter + 2);
			_21$$10 = 0;
			if (ZEPHIR_GE_LONG(&_23$$10, _22$$10)) {
				while (1) {
					if (_21$$10) {
						_22$$10 += 2;
						if (!(ZEPHIR_GE_LONG(&_23$$10, _22$$10))) {
							break;
						}
					} else {
						_21$$10 = 1;
					}
					i = _22$$10;
					_24$$11 = zephir_array_isset_long(&uri_array, i);
					if (_24$$11) {
						_24$$11 = zephir_array_isset_long(&uri_array, (i + 1));
					}
					if (_24$$11) {
						zephir_array_fetch_long(&_25$$12, &uri_array, (i + 1), PH_NOISY | PH_READONLY, "hachi/routes.zep", 76 TSRMLS_CC);
						ZEPHIR_OBS_NVAR(&_26$$12);
						zephir_array_fetch_long(&_26$$12, &uri_array, i, PH_NOISY, "hachi/routes.zep", 76 TSRMLS_CC);
						zephir_array_update_zval(&params, &_26$$12, &_25$$12, PH_COPY | PH_SEPARATE);
					}
				}
			}
		}
	} else {
		ZEPHIR_INIT_NVAR(&action);
		ZVAL_STRING(&action, "index");
	}
	ZEPHIR_CALL_FUNCTION(&_27, "array_merge", NULL, 16, &params, &param_get, &param_post);
	zephir_check_call_status();
	ZEPHIR_CPY_WRT(&params, &_27);
	ZEPHIR_INIT_VAR(&pattern);
	ZVAL_STRING(&pattern, "/^[A-Za-z0-9]+$/");
	ZEPHIR_INIT_VAR(&_28);
	ZEPHIR_INIT_VAR(&_29);
	zephir_preg_match(&_29, &pattern, &controller, &_28, 0, 0 , 0  TSRMLS_CC);
	if (!(zephir_is_true(&_29))) {
		code = 10001;
	}
	ZEPHIR_INIT_VAR(&_30);
	ZEPHIR_INIT_VAR(&_31);
	zephir_preg_match(&_31, &pattern, &action, &_30, 0, 0 , 0  TSRMLS_CC);
	if (!(zephir_is_true(&_31))) {
		code = 10002;
	}
	ZEPHIR_INIT_VAR(&ret);
	zephir_create_array(&ret, 5, 0 TSRMLS_CC);
	ZEPHIR_INIT_VAR(&_32);
	ZVAL_LONG(&_32, code);
	zephir_array_update_string(&ret, SL("code"), &_32, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&ret, SL("group"), &group, PH_COPY | PH_SEPARATE);
	ZEPHIR_INIT_NVAR(&_32);
	zephir_ucfirst(&_32, &controller);
	zephir_array_update_string(&ret, SL("controller"), &_32, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&ret, SL("action"), &action, PH_COPY | PH_SEPARATE);
	ZEPHIR_INIT_VAR(&_33);
	zephir_create_array(&_33, 3, 0 TSRMLS_CC);
	zephir_array_update_string(&_33, SL("query"), &params, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&_33, SL("get"), &param_get, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&_33, SL("post"), &param_post, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&ret, SL("params"), &_33, PH_COPY | PH_SEPARATE);
	RETURN_CTOR(ret);

}

PHP_METHOD(Hachi_Routes, __dealRouteMethod) {

	zend_string *_3;
	zend_ulong _2;
	int ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_6 = NULL;
	zval *uri_param = NULL, ret, p, v, _0, *_1, _4$$3, _5$$3;
	zval uri, pattern$$3, replace$$3;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&uri);
	ZVAL_UNDEF(&pattern$$3);
	ZVAL_UNDEF(&replace$$3);
	ZVAL_UNDEF(&ret);
	ZVAL_UNDEF(&p);
	ZVAL_UNDEF(&v);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$3);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &uri_param);

	zephir_get_strval(&uri, uri_param);


	ZEPHIR_CPY_WRT(&ret, &uri);
	zephir_read_property(&_0, this_ptr, SL("include_method_array"), PH_NOISY_CC | PH_READONLY);
	zephir_is_iterable(&_0, 0, "hachi/routes.zep", 124);
	ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&_0), _2, _3, _1)
	{
		ZEPHIR_INIT_NVAR(&p);
		if (_3 != NULL) { 
			ZVAL_STR_COPY(&p, _3);
		} else {
			ZVAL_LONG(&p, _2);
		}
		ZEPHIR_INIT_NVAR(&v);
		ZVAL_COPY(&v, _1);
		zephir_get_strval(&pattern$$3, &p);
		zephir_get_strval(&replace$$3, &v);
		ZEPHIR_INIT_NVAR(&_4$$3);
		ZEPHIR_INIT_NVAR(&_5$$3);
		zephir_preg_match(&_5$$3, &pattern$$3, &uri, &_4$$3, 0, 0 , 0  TSRMLS_CC);
		if (zephir_is_true(&_5$$3)) {
			ZEPHIR_CALL_FUNCTION(&ret, "preg_replace", &_6, 17, &pattern$$3, &replace$$3, &uri);
			zephir_check_call_status();
			break;
		}
	} ZEND_HASH_FOREACH_END();
	ZEPHIR_INIT_NVAR(&v);
	ZEPHIR_INIT_NVAR(&p);
	RETURN_CCTOR(ret);

}

