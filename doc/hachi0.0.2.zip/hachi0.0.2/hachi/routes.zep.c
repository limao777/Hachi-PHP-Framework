
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/object.h"
#include "kernel/memory.h"
#include "kernel/string.h"
#include "kernel/operators.h"
#include "kernel/fcall.h"
#include "kernel/hash.h"
#include "kernel/array.h"


ZEPHIR_INIT_CLASS(Hachi_Routes) {

	ZEPHIR_REGISTER_CLASS(Hachi, Routes, hachi, routes, hachi_routes_method_entry, 0);

	zend_declare_property_null(hachi_routes_ce, SL("include_method_array"), ZEND_ACC_PRIVATE TSRMLS_CC);

	zend_declare_property_null(hachi_routes_ce, SL("route_group"), ZEND_ACC_PRIVATE TSRMLS_CC);

	return SUCCESS;

}

PHP_METHOD(Hachi_Routes, uriPraser) {

	zend_bool _19$$9, _20$$10, _23$$11;
	zend_string *_12;
	zend_ulong _11;
	zephir_fcall_cache_entry *_14 = NULL;
	int ZEPHIR_LAST_CALL_STATUS, uri_counter = 0, code = 0, i = 0, _21$$10;
	zval route_group, method_arr, param_get, param_post, params, ret, _32;
	zval *uri_param = NULL, *route_group_param = NULL, *method_arr_param = NULL, *param_get_param = NULL, *param_post_param = NULL, group, controller, action, uri_array, p, v, uri_array_length, _0, _1, _6, _7, _8, _9, *_10, _26, _27, _28, _29, _30, _31, _2$$3, _3$$3, _4$$3, _5$$3, _13$$4, _15$$5, _16$$5, _17$$5, _18$$5, _22$$10, _24$$12, _25$$12;
	zval uri, pattern;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&uri);
	ZVAL_UNDEF(&pattern);
	ZVAL_UNDEF(&group);
	ZVAL_UNDEF(&controller);
	ZVAL_UNDEF(&action);
	ZVAL_UNDEF(&uri_array);
	ZVAL_UNDEF(&p);
	ZVAL_UNDEF(&v);
	ZVAL_UNDEF(&uri_array_length);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_6);
	ZVAL_UNDEF(&_7);
	ZVAL_UNDEF(&_8);
	ZVAL_UNDEF(&_9);
	ZVAL_UNDEF(&_26);
	ZVAL_UNDEF(&_27);
	ZVAL_UNDEF(&_28);
	ZVAL_UNDEF(&_29);
	ZVAL_UNDEF(&_30);
	ZVAL_UNDEF(&_31);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$3);
	ZVAL_UNDEF(&_13$$4);
	ZVAL_UNDEF(&_15$$5);
	ZVAL_UNDEF(&_16$$5);
	ZVAL_UNDEF(&_17$$5);
	ZVAL_UNDEF(&_18$$5);
	ZVAL_UNDEF(&_22$$10);
	ZVAL_UNDEF(&_24$$12);
	ZVAL_UNDEF(&_25$$12);
	ZVAL_UNDEF(&route_group);
	ZVAL_UNDEF(&method_arr);
	ZVAL_UNDEF(&param_get);
	ZVAL_UNDEF(&param_post);
	ZVAL_UNDEF(&params);
	ZVAL_UNDEF(&ret);
	ZVAL_UNDEF(&_32);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 5, 0, &uri_param, &route_group_param, &method_arr_param, &param_get_param, &param_post_param);

	zephir_get_strval(&uri, uri_param);
	zephir_get_arrval(&route_group, route_group_param);
	zephir_get_arrval(&method_arr, method_arr_param);
	zephir_get_arrval(&param_get, param_get_param);
	zephir_get_arrval(&param_post, param_post_param);


	zephir_update_property_zval(this_ptr, SL("include_method_array"), &method_arr);
	zephir_update_property_zval(this_ptr, SL("route_group"), &route_group);
	uri_counter = 0;
	code = 0;
	ZEPHIR_INIT_VAR(&group);
	ZVAL_NULL(&group);
	ZEPHIR_INIT_VAR(&controller);
	ZVAL_NULL(&controller);
	ZEPHIR_INIT_VAR(&action);
	ZVAL_NULL(&action);
	ZEPHIR_INIT_VAR(&params);
	array_init(&params);
	ZEPHIR_INIT_VAR(&_0);
	ZVAL_STRING(&_0, "?");
	ZEPHIR_INIT_VAR(&_1);
	zephir_fast_strpos(&_1, &uri, &_0, 0 );
	if (ZEPHIR_GT_LONG(&_1, 0)) {
		ZEPHIR_INIT_VAR(&_2$$3);
		ZVAL_STRING(&_2$$3, "?");
		ZEPHIR_INIT_VAR(&_3$$3);
		zephir_fast_strpos(&_3$$3, &uri, &_2$$3, 0 );
		ZVAL_LONG(&_4$$3, 0);
		ZEPHIR_CALL_FUNCTION(&_5$$3, "mb_substr", NULL, 13, &uri, &_4$$3, &_3$$3);
		zephir_check_call_status();
		zephir_get_strval(&uri, &_5$$3);
	}
	ZEPHIR_CALL_METHOD(&_6, this_ptr, "__dealroutemethod", NULL, 14, &uri);
	zephir_check_call_status();
	zephir_get_strval(&uri, &_6);
	ZEPHIR_INIT_VAR(&_7);
	ZEPHIR_INIT_VAR(&_8);
	ZVAL_STRING(&_8, "/");
	zephir_fast_trim(&_7, &uri, &_8, ZEPHIR_TRIM_LEFT TSRMLS_CC);
	zephir_get_strval(&uri, &_7);
	zephir_read_property(&_9, this_ptr, SL("route_group"), PH_NOISY_CC | PH_READONLY);
	zephir_is_iterable(&_9, 0, "hachi/routes.zep", 56);
	ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&_9), _11, _12, _10)
	{
		ZEPHIR_INIT_NVAR(&p);
		if (_12 != NULL) { 
			ZVAL_STR_COPY(&p, _12);
		} else {
			ZVAL_LONG(&p, _11);
		}
		ZEPHIR_INIT_NVAR(&v);
		ZVAL_COPY(&v, _10);
		ZEPHIR_CALL_FUNCTION(&_13$$4, "stripos", &_14, 15, &uri, &p);
		zephir_check_call_status();
		if (ZEPHIR_IS_LONG_IDENTICAL(&_13$$4, 0)) {
			ZEPHIR_CPY_WRT(&group, &v);
			ZVAL_LONG(&_15$$5, zephir_fast_strlen_ev(&p));
			ZEPHIR_CALL_FUNCTION(&_16$$5, "mb_substr", NULL, 13, &uri, &_15$$5);
			zephir_check_call_status();
			zephir_get_strval(&uri, &_16$$5);
			ZEPHIR_INIT_NVAR(&_17$$5);
			ZEPHIR_INIT_NVAR(&_18$$5);
			ZVAL_STRING(&_18$$5, "/");
			zephir_fast_trim(&_17$$5, &uri, &_18$$5, ZEPHIR_TRIM_LEFT TSRMLS_CC);
			zephir_get_strval(&uri, &_17$$5);
		}
	} ZEND_HASH_FOREACH_END();
	ZEPHIR_INIT_NVAR(&v);
	ZEPHIR_INIT_NVAR(&p);
	ZEPHIR_INIT_VAR(&uri_array);
	zephir_fast_explode_str(&uri_array, SL("/"), &uri, LONG_MAX TSRMLS_CC);
	if (zephir_array_isset_long(&uri_array, uri_counter)) {
		ZEPHIR_OBS_NVAR(&controller);
		zephir_array_fetch_long(&controller, &uri_array, uri_counter, PH_NOISY, "hachi/routes.zep", 59 TSRMLS_CC);
	} else {
		ZEPHIR_INIT_NVAR(&controller);
		ZVAL_STRING(&controller, "welcome");
	}
	if (ZEPHIR_IS_EMPTY(&controller)) {
		ZEPHIR_INIT_NVAR(&controller);
		ZVAL_STRING(&controller, "welcome");
	}
	if (zephir_array_isset_long(&uri_array, (uri_counter + 1))) {
		ZEPHIR_OBS_NVAR(&action);
		zephir_array_fetch_long(&action, &uri_array, (uri_counter + 1), PH_NOISY, "hachi/routes.zep", 68 TSRMLS_CC);
		ZEPHIR_INIT_VAR(&uri_array_length);
		ZVAL_LONG(&uri_array_length, zephir_fast_count_int(&uri_array TSRMLS_CC));
		_19$$9 = ZEPHIR_GT_LONG(&uri_array_length, ((uri_counter + 2)));
		if (_19$$9) {
			_19$$9 = ZEPHIR_LT_LONG(&uri_array_length, 101);
		}
		if (_19$$9) {
			ZEPHIR_CPY_WRT(&_22$$10, &uri_array_length);
			_21$$10 = (uri_counter + 2);
			_20$$10 = 0;
			if (ZEPHIR_GE_LONG(&_22$$10, _21$$10)) {
				while (1) {
					if (_20$$10) {
						_21$$10 += 2;
						if (!(ZEPHIR_GE_LONG(&_22$$10, _21$$10))) {
							break;
						}
					} else {
						_20$$10 = 1;
					}
					i = _21$$10;
					_23$$11 = zephir_array_isset_long(&uri_array, i);
					if (_23$$11) {
						_23$$11 = zephir_array_isset_long(&uri_array, (i + 1));
					}
					if (_23$$11) {
						zephir_array_fetch_long(&_24$$12, &uri_array, (i + 1), PH_NOISY | PH_READONLY, "hachi/routes.zep", 76 TSRMLS_CC);
						ZEPHIR_OBS_NVAR(&_25$$12);
						zephir_array_fetch_long(&_25$$12, &uri_array, i, PH_NOISY, "hachi/routes.zep", 76 TSRMLS_CC);
						zephir_array_update_zval(&params, &_25$$12, &_24$$12, PH_COPY | PH_SEPARATE);
					}
				}
			}
		}
	} else {
		ZEPHIR_INIT_NVAR(&action);
		ZVAL_STRING(&action, "index");
	}
	ZEPHIR_CALL_FUNCTION(&_26, "array_merge", NULL, 16, &params, &param_get, &param_post);
	zephir_check_call_status();
	ZEPHIR_CPY_WRT(&params, &_26);
	ZEPHIR_INIT_VAR(&pattern);
	ZVAL_STRING(&pattern, "/^[A-Za-z0-9]+$/");
	ZEPHIR_INIT_VAR(&_27);
	ZEPHIR_INIT_VAR(&_28);
	zephir_preg_match(&_28, &pattern, &controller, &_27, 0, 0 , 0  TSRMLS_CC);
	if (!(zephir_is_true(&_28))) {
		code = 10001;
	}
	ZEPHIR_INIT_VAR(&_29);
	ZEPHIR_INIT_VAR(&_30);
	zephir_preg_match(&_30, &pattern, &action, &_29, 0, 0 , 0  TSRMLS_CC);
	if (!(zephir_is_true(&_30))) {
		code = 10002;
	}
	ZEPHIR_INIT_VAR(&ret);
	zephir_create_array(&ret, 5, 0 TSRMLS_CC);
	ZEPHIR_INIT_VAR(&_31);
	ZVAL_LONG(&_31, code);
	zephir_array_update_string(&ret, SL("code"), &_31, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&ret, SL("group"), &group, PH_COPY | PH_SEPARATE);
	ZEPHIR_INIT_NVAR(&_31);
	zephir_ucfirst(&_31, &controller);
	zephir_array_update_string(&ret, SL("controller"), &_31, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&ret, SL("action"), &action, PH_COPY | PH_SEPARATE);
	ZEPHIR_INIT_VAR(&_32);
	zephir_create_array(&_32, 3, 0 TSRMLS_CC);
	zephir_array_update_string(&_32, SL("query"), &params, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&_32, SL("get"), &param_get, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&_32, SL("post"), &param_post, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&ret, SL("params"), &_32, PH_COPY | PH_SEPARATE);
	RETURN_CTOR(ret);

}

PHP_METHOD(Hachi_Routes, __dealRouteMethod) {

	zend_string *_3;
	zend_ulong _2;
	int ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_6 = NULL;
	zval *uri_param = NULL, ret, p, v, _0, *_1, _4$$3, _5$$3;
	zval uri, pattern$$3, replace$$3;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&uri);
	ZVAL_UNDEF(&pattern$$3);
	ZVAL_UNDEF(&replace$$3);
	ZVAL_UNDEF(&ret);
	ZVAL_UNDEF(&p);
	ZVAL_UNDEF(&v);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$3);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &uri_param);

	zephir_get_strval(&uri, uri_param);


	ZEPHIR_CPY_WRT(&ret, &uri);
	zephir_read_property(&_0, this_ptr, SL("include_method_array"), PH_NOISY_CC | PH_READONLY);
	zephir_is_iterable(&_0, 0, "hachi/routes.zep", 124);
	ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&_0), _2, _3, _1)
	{
		ZEPHIR_INIT_NVAR(&p);
		if (_3 != NULL) { 
			ZVAL_STR_COPY(&p, _3);
		} else {
			ZVAL_LONG(&p, _2);
		}
		ZEPHIR_INIT_NVAR(&v);
		ZVAL_COPY(&v, _1);
		zephir_get_strval(&pattern$$3, &p);
		zephir_get_strval(&replace$$3, &v);
		ZEPHIR_INIT_NVAR(&_4$$3);
		ZEPHIR_INIT_NVAR(&_5$$3);
		zephir_preg_match(&_5$$3, &pattern$$3, &uri, &_4$$3, 0, 0 , 0  TSRMLS_CC);
		if (zephir_is_true(&_5$$3)) {
			ZEPHIR_CALL_FUNCTION(&ret, "preg_replace", &_6, 17, &pattern$$3, &replace$$3, &uri);
			zephir_check_call_status();
			break;
		}
	} ZEND_HASH_FOREACH_END();
	ZEPHIR_INIT_NVAR(&v);
	ZEPHIR_INIT_NVAR(&p);
	RETURN_CCTOR(ret);

}

