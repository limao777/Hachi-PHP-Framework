
extern zend_class_entry *hachi_routes_ce;

ZEPHIR_INIT_CLASS(Hachi_Routes);

PHP_METHOD(Hachi_Routes, uriPraser);
PHP_METHOD(Hachi_Routes, __dealRouteMethod);

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_routes_uripraser, 0, 0, 5)
	ZEND_ARG_INFO(0, uri)
	ZEND_ARG_ARRAY_INFO(0, route_group, 0)
	ZEND_ARG_ARRAY_INFO(0, method_arr, 0)
	ZEND_ARG_ARRAY_INFO(0, param_get, 0)
	ZEND_ARG_ARRAY_INFO(0, param_post, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_routes___dealroutemethod, 0, 0, 1)
	ZEND_ARG_INFO(0, uri)
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(hachi_routes_method_entry) {
	PHP_ME(Hachi_Routes, uriPraser, arginfo_hachi_routes_uripraser, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Routes, __dealRouteMethod, arginfo_hachi_routes___dealroutemethod, ZEND_ACC_PRIVATE)
	PHP_FE_END
};
