
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/memory.h"
#include "kernel/string.h"
#include "kernel/operators.h"
#include "kernel/object.h"
#include "kernel/array.h"
#include "kernel/fcall.h"
#include "kernel/file.h"
#include "kernel/require.h"
#include "kernel/exception.h"


ZEPHIR_INIT_CLASS(Hachi_Run) {

	ZEPHIR_REGISTER_CLASS(Hachi, Run, hachi, run, hachi_run_method_entry, 0);

	zend_declare_property_null(hachi_run_ce, SL("conf"), ZEND_ACC_PUBLIC|ZEND_ACC_STATIC TSRMLS_CC);

	return SUCCESS;

}

PHP_METHOD(Hachi_Run, handleloader) {

	int ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_5 = NULL;
	zval *class_name_param = NULL, t, require_path, _0, _1, _2, _3, _4, _6$$3, _7$$3, _8$$3, _9$$4, _10$$4, _11$$4, _12$$5, _13$$5, _14$$5;
	zval class_name;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&class_name);
	ZVAL_UNDEF(&t);
	ZVAL_UNDEF(&require_path);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_4);
	ZVAL_UNDEF(&_6$$3);
	ZVAL_UNDEF(&_7$$3);
	ZVAL_UNDEF(&_8$$3);
	ZVAL_UNDEF(&_9$$4);
	ZVAL_UNDEF(&_10$$4);
	ZVAL_UNDEF(&_11$$4);
	ZVAL_UNDEF(&_12$$5);
	ZVAL_UNDEF(&_13$$5);
	ZVAL_UNDEF(&_14$$5);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &class_name_param);

	zephir_get_strval(&class_name, class_name_param);


	ZEPHIR_INIT_VAR(&_0);
	ZEPHIR_INIT_VAR(&_1);
	ZVAL_STRING(&_1, "_");
	ZEPHIR_INIT_VAR(&_2);
	ZVAL_STRING(&_2, "/");
	zephir_fast_str_replace(&_0, &_1, &_2, &class_name TSRMLS_CC);
	zephir_get_strval(&class_name, &_0);
	zephir_read_static_property_ce(&_3, hachi_run_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	ZEPHIR_OBS_VAR(&t);
	zephir_array_fetch_string(&t, &_3, SL("www"), PH_NOISY, "hachi/run.zep", 13 TSRMLS_CC);
	ZEPHIR_INIT_VAR(&_4);
	ZVAL_STRING(&_4, "%s/%s.php");
	ZEPHIR_CALL_FUNCTION(&require_path, "sprintf", &_5, 6, &_4, &t, &class_name);
	zephir_check_call_status();
	if ((zephir_file_exists(&require_path TSRMLS_CC) == SUCCESS)) {
		if (zephir_require_zval(&require_path TSRMLS_CC) == FAILURE) {
			RETURN_MM_NULL();
		}
		ZEPHIR_INIT_VAR(&_6$$3);
		ZEPHIR_INIT_VAR(&_7$$3);
		ZVAL_STRING(&_7$$3, "/");
		ZEPHIR_INIT_VAR(&_8$$3);
		ZVAL_STRING(&_8$$3, "_");
		zephir_fast_str_replace(&_6$$3, &_7$$3, &_8$$3, &class_name TSRMLS_CC);
		zephir_get_strval(&class_name, &_6$$3);
		if (!(zephir_class_exists(&class_name, 1 TSRMLS_CC))) {
			ZEPHIR_INIT_VAR(&_9$$4);
			object_init_ex(&_9$$4, zend_exception_get_default(TSRMLS_C));
			ZEPHIR_INIT_VAR(&_10$$4);
			ZVAL_STRING(&_10$$4, "Found class error: %s");
			ZEPHIR_CALL_FUNCTION(&_11$$4, "sprintf", &_5, 6, &_10$$4, &class_name);
			zephir_check_call_status();
			ZEPHIR_CALL_METHOD(NULL, &_9$$4, "__construct", NULL, 11, &_11$$4);
			zephir_check_call_status();
			zephir_throw_exception_debug(&_9$$4, "hachi/run.zep", 19 TSRMLS_CC);
			ZEPHIR_MM_RESTORE();
			return;
		}
	} else {
		ZEPHIR_INIT_VAR(&_12$$5);
		object_init_ex(&_12$$5, zend_exception_get_default(TSRMLS_C));
		ZEPHIR_INIT_VAR(&_13$$5);
		ZVAL_STRING(&_13$$5, "Not Found class : %s");
		ZEPHIR_CALL_FUNCTION(&_14$$5, "sprintf", &_5, 6, &_13$$5, &class_name);
		zephir_check_call_status();
		ZEPHIR_CALL_METHOD(NULL, &_12$$5, "__construct", NULL, 11, &_14$$5);
		zephir_check_call_status();
		zephir_throw_exception_debug(&_12$$5, "hachi/run.zep", 22 TSRMLS_CC);
		ZEPHIR_MM_RESTORE();
		return;
	}
	RETURN_MM_LONG(1);

}

PHP_METHOD(Hachi_Run, init) {

	int ZEPHIR_LAST_CALL_STATUS;
	zval *configserver_param = NULL, _0;
	zval configserver;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&configserver);
	ZVAL_UNDEF(&_0);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &configserver_param);

	zephir_get_arrval(&configserver, configserver_param);


	zephir_update_static_property_ce(hachi_run_ce, SL("conf"), &configserver);
	ZEPHIR_INIT_VAR(&_0);
	ZEPHIR_INIT_NVAR(&_0);
	zephir_create_closure_ex(&_0, NULL, hachi_1__closure_ce, SL("__invoke"));
	ZEPHIR_CALL_FUNCTION(NULL, "spl_autoload_register", NULL, 1, &_0);
	zephir_check_call_status();
	RETURN_MM_LONG(1);

}

PHP_METHOD(Hachi_Run, CHttpServer) {

	zval _5, _6;
	zval __$true, http, http_port, http_set_tmp, _0, _2, _3, _4, _7, _1$$3;
	int ZEPHIR_LAST_CALL_STATUS;
	ZEPHIR_INIT_THIS();

	ZVAL_BOOL(&__$true, 1);
	ZVAL_UNDEF(&http);
	ZVAL_UNDEF(&http_port);
	ZVAL_UNDEF(&http_set_tmp);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_4);
	ZVAL_UNDEF(&_7);
	ZVAL_UNDEF(&_1$$3);
	ZVAL_UNDEF(&_5);
	ZVAL_UNDEF(&_6);

	ZEPHIR_MM_GROW();

	zephir_read_static_property_ce(&_0, hachi_run_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	if (zephir_array_isset_string(&_0, SL("http_port"))) {
		zephir_read_static_property_ce(&_1$$3, hachi_run_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_OBS_VAR(&http_port);
		zephir_array_fetch_string(&http_port, &_1$$3, SL("http_port"), PH_NOISY, "hachi/run.zep", 57 TSRMLS_CC);
	} else {
		ZEPHIR_INIT_NVAR(&http_port);
		ZVAL_LONG(&http_port, 10080);
	}
	ZEPHIR_INIT_VAR(&http);
	object_init_ex(&http, zephir_get_internal_ce(SL("swoole_http_server")));
	ZEPHIR_INIT_VAR(&_2);
	ZVAL_STRING(&_2, "0.0.0.0");
	ZEPHIR_CALL_METHOD(NULL, &http, "__construct", NULL, 0, &_2, &http_port);
	zephir_check_call_status();
	ZEPHIR_INIT_VAR(&http_set_tmp);
	zephir_create_array(&http_set_tmp, 6, 0 TSRMLS_CC);
	add_assoc_long_ex(&http_set_tmp, SL("worker_num"), 16);
	zephir_array_update_string(&http_set_tmp, SL("daemonize"), &__$true, PH_COPY | PH_SEPARATE);
	add_assoc_long_ex(&http_set_tmp, SL("max_request"), 10000);
	add_assoc_long_ex(&http_set_tmp, SL("dispatch_mode"), 1);
	zephir_read_static_property_ce(&_3, hachi_run_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	ZEPHIR_OBS_VAR(&_4);
	zephir_array_fetch_string(&_4, &_3, SL("logfile"), PH_NOISY, "hachi/run.zep", 62 TSRMLS_CC);
	zephir_array_update_string(&http_set_tmp, SL("log_file"), &_4, PH_COPY | PH_SEPARATE);
	add_assoc_long_ex(&http_set_tmp, SL("log_level"), 2);
	ZEPHIR_CALL_METHOD(NULL, &http, "set", NULL, 0, &http_set_tmp);
	zephir_check_call_status();
	ZEPHIR_INIT_VAR(&_5);
	zephir_create_array(&_5, 2, 0 TSRMLS_CC);
	zephir_array_fast_append(&_5, this_ptr);
	ZEPHIR_INIT_NVAR(&_2);
	ZVAL_STRING(&_2, "onHTTPMasterStart");
	zephir_array_fast_append(&_5, &_2);
	ZEPHIR_INIT_NVAR(&_2);
	ZVAL_STRING(&_2, "Start");
	ZEPHIR_CALL_METHOD(NULL, &http, "on", NULL, 0, &_2, &_5);
	zephir_check_call_status();
	ZEPHIR_INIT_VAR(&_6);
	zephir_create_array(&_6, 2, 0 TSRMLS_CC);
	zephir_array_fast_append(&_6, this_ptr);
	ZEPHIR_INIT_NVAR(&_2);
	ZVAL_STRING(&_2, "onHTTPWorkerStart");
	zephir_array_fast_append(&_6, &_2);
	ZEPHIR_INIT_NVAR(&_2);
	ZVAL_STRING(&_2, "WorkerStart");
	ZEPHIR_CALL_METHOD(NULL, &http, "on", NULL, 0, &_2, &_6);
	zephir_check_call_status();
	ZEPHIR_INIT_NVAR(&_2);
	ZEPHIR_INIT_NVAR(&_2);
	zephir_create_closure_ex(&_2, NULL, hachi_2__closure_ce, SL("__invoke"));
	ZEPHIR_INIT_VAR(&_7);
	ZVAL_STRING(&_7, "request");
	ZEPHIR_CALL_METHOD(NULL, &http, "on", NULL, 0, &_7, &_2);
	zephir_check_call_status();
	ZEPHIR_CALL_METHOD(NULL, &http, "start", NULL, 0);
	zephir_check_call_status();
	ZEPHIR_MM_RESTORE();

}

PHP_METHOD(Hachi_Run, onHTTPMasterStart) {

	int ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_4 = NULL;
	zval *http, http_sub, _0, _1, _2, _3, _5, _6, _7, _8, _9;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&http_sub);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_5);
	ZVAL_UNDEF(&_6);
	ZVAL_UNDEF(&_7);
	ZVAL_UNDEF(&_8);
	ZVAL_UNDEF(&_9);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &http);



	zephir_read_static_property_ce(&_0, hachi_run_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	zephir_array_fetch_string(&_1, &_0, SL("log"), PH_NOISY | PH_READONLY, "hachi/run.zep", 77 TSRMLS_CC);
	ZEPHIR_INIT_VAR(&_2);
	ZVAL_STRING(&_2, "%s/HTTPmasterId");
	ZEPHIR_CALL_FUNCTION(&_3, "sprintf", &_4, 6, &_2, &_1);
	zephir_check_call_status();
	zephir_read_property(&_5, http, SL("master_pid"), PH_NOISY_CC | PH_READONLY);
	zephir_file_put_contents(NULL, &_3, &_5 TSRMLS_CC);
	zephir_read_static_property_ce(&_6, hachi_run_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	zephir_array_fetch_string(&_7, &_6, SL("log"), PH_NOISY | PH_READONLY, "hachi/run.zep", 78 TSRMLS_CC);
	ZEPHIR_INIT_NVAR(&_2);
	ZVAL_STRING(&_2, "%s/HTTPmanagerId");
	ZEPHIR_CALL_FUNCTION(&_8, "sprintf", &_4, 6, &_2, &_7);
	zephir_check_call_status();
	zephir_read_property(&_9, http, SL("manager_pid"), PH_NOISY_CC | PH_READONLY);
	zephir_file_put_contents(NULL, &_8, &_9 TSRMLS_CC);
	ZEPHIR_MM_RESTORE();

}

PHP_METHOD(Hachi_Run, onHTTPWorkerStart) {

	zval _0, _1, _2, _3, _5, _6, _7;
	int ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_4 = NULL;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3);
	ZVAL_UNDEF(&_5);
	ZVAL_UNDEF(&_6);
	ZVAL_UNDEF(&_7);

	ZEPHIR_MM_GROW();

	zephir_read_static_property_ce(&_0, hachi_run_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	zephir_array_fetch_string(&_1, &_0, SL("server"), PH_NOISY | PH_READONLY, "hachi/run.zep", 83 TSRMLS_CC);
	ZEPHIR_INIT_VAR(&_2);
	ZVAL_STRING(&_2, "%s/Logging.php");
	ZEPHIR_CALL_FUNCTION(&_3, "sprintf", &_4, 6, &_2, &_1);
	zephir_check_call_status();
	if (zephir_require_zval(&_3 TSRMLS_CC) == FAILURE) {
		RETURN_MM_NULL();
	}
	zephir_read_static_property_ce(&_5, hachi_run_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	zephir_array_fetch_string(&_6, &_5, SL("server"), PH_NOISY | PH_READONLY, "hachi/run.zep", 84 TSRMLS_CC);
	ZEPHIR_INIT_NVAR(&_2);
	ZVAL_STRING(&_2, "%s/Routes.php");
	ZEPHIR_CALL_FUNCTION(&_7, "sprintf", &_4, 6, &_2, &_6);
	zephir_check_call_status();
	if (zephir_require_zval(&_7 TSRMLS_CC) == FAILURE) {
		RETURN_MM_NULL();
	}
	ZEPHIR_MM_RESTORE();

}

