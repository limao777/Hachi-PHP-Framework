
extern zend_class_entry *hachi_run_ce;

ZEPHIR_INIT_CLASS(Hachi_Run);

PHP_METHOD(Hachi_Run, handleloader);
PHP_METHOD(Hachi_Run, init);
PHP_METHOD(Hachi_Run, CHttpServer);
PHP_METHOD(Hachi_Run, onHTTPMasterStart);
PHP_METHOD(Hachi_Run, onHTTPWorkerStart);

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_run_handleloader, 0, 0, 1)
	ZEND_ARG_INFO(0, class_name)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_run_init, 0, 0, 1)
	ZEND_ARG_ARRAY_INFO(0, configserver, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_hachi_run_onhttpmasterstart, 0, 0, 1)
	ZEND_ARG_INFO(0, http)
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(hachi_run_method_entry) {
	PHP_ME(Hachi_Run, handleloader, arginfo_hachi_run_handleloader, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Run, init, arginfo_hachi_run_init, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Run, CHttpServer, NULL, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Run, onHTTPMasterStart, arginfo_hachi_run_onhttpmasterstart, ZEND_ACC_PUBLIC)
	PHP_ME(Hachi_Run, onHTTPWorkerStart, NULL, ZEND_ACC_PUBLIC)
	PHP_FE_END
};
