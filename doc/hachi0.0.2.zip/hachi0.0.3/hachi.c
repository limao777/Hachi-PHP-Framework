
/* This file was generated automatically by Zephir do not modify it! */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <php.h>

#include "php_ext.h"
#include "hachi.h"

#include <ext/standard/info.h>

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/globals.h"
#include "kernel/main.h"
#include "kernel/fcall.h"
#include "kernel/memory.h"



zend_class_entry *hachi_0__closure_ce;
zend_class_entry *hachi_app_ce;
zend_class_entry *hachi_ctx_ce;
zend_class_entry *hachi_routes_ce;

ZEND_DECLARE_MODULE_GLOBALS(hachi)

PHP_INI_BEGIN()
	
PHP_INI_END()

static PHP_MINIT_FUNCTION(hachi)
{
	REGISTER_INI_ENTRIES();
	ZEPHIR_INIT(Hachi_App);
	ZEPHIR_INIT(Hachi_Ctx);
	ZEPHIR_INIT(Hachi_Routes);
	ZEPHIR_INIT(hachi_0__closure);
	return SUCCESS;
}

#ifndef ZEPHIR_RELEASE
static PHP_MSHUTDOWN_FUNCTION(hachi)
{
	zephir_deinitialize_memory(TSRMLS_C);
	UNREGISTER_INI_ENTRIES();
	return SUCCESS;
}
#endif

/**
 * Initialize globals on each request or each thread started
 */
static void php_zephir_init_globals(zend_hachi_globals *hachi_globals TSRMLS_DC)
{
	hachi_globals->initialized = 0;

	/* Memory options */
	hachi_globals->active_memory = NULL;

	/* Virtual Symbol Tables */
	hachi_globals->active_symbol_table = NULL;

	/* Cache Enabled */
	hachi_globals->cache_enabled = 1;

	/* Recursive Lock */
	hachi_globals->recursive_lock = 0;

	/* Static cache */
	memset(hachi_globals->scache, '\0', sizeof(zephir_fcall_cache_entry*) * ZEPHIR_MAX_CACHE_SLOTS);


}

/**
 * Initialize globals only on each thread started
 */
static void php_zephir_init_module_globals(zend_hachi_globals *hachi_globals TSRMLS_DC)
{

}

static PHP_RINIT_FUNCTION(hachi)
{

	zend_hachi_globals *hachi_globals_ptr;
#ifdef ZTS
	tsrm_ls = ts_resource(0);
#endif
	hachi_globals_ptr = ZEPHIR_VGLOBAL;

	php_zephir_init_globals(hachi_globals_ptr TSRMLS_CC);
	zephir_initialize_memory(hachi_globals_ptr TSRMLS_CC);


	return SUCCESS;
}

static PHP_RSHUTDOWN_FUNCTION(hachi)
{
	
	zephir_deinitialize_memory(TSRMLS_C);
	return SUCCESS;
}

static PHP_MINFO_FUNCTION(hachi)
{
	php_info_print_box_start(0);
	php_printf("%s", PHP_HACHI_DESCRIPTION);
	php_info_print_box_end();


        php_info_print_table_start();
        php_info_print_table_header(2, PHP_HACHI_NAME, "enabled");
        php_info_print_table_row(2, "CGI Server", "on");
        php_info_print_table_row(2, "FPM Server", "on");
        php_info_print_table_row(2, "Route Ana", "on");
        php_info_print_table_row(2, "App handler", "on");
        php_info_print_table_row(2, "Version", PHP_HACHI_VERSION);
        php_info_print_table_row(2, "Build Date", __DATE__ " " __TIME__ );
        php_info_print_table_end();

	DISPLAY_INI_ENTRIES();
}

static PHP_GINIT_FUNCTION(hachi)
{
	php_zephir_init_globals(hachi_globals TSRMLS_CC);
	php_zephir_init_module_globals(hachi_globals TSRMLS_CC);
}

static PHP_GSHUTDOWN_FUNCTION(hachi)
{

}


zend_function_entry php_hachi_functions[] = {
ZEND_FE_END

};

zend_module_entry hachi_module_entry = {
	STANDARD_MODULE_HEADER_EX,
	NULL,
	NULL,
	PHP_HACHI_EXTNAME,
	php_hachi_functions,
	PHP_MINIT(hachi),
#ifndef ZEPHIR_RELEASE
	PHP_MSHUTDOWN(hachi),
#else
	NULL,
#endif
	PHP_RINIT(hachi),
	PHP_RSHUTDOWN(hachi),
	PHP_MINFO(hachi),
	PHP_HACHI_VERSION,
	ZEND_MODULE_GLOBALS(hachi),
	PHP_GINIT(hachi),
	PHP_GSHUTDOWN(hachi),
	NULL,
	STANDARD_MODULE_PROPERTIES_EX
};

#ifdef COMPILE_DL_HACHI
ZEND_GET_MODULE(hachi)
#endif
