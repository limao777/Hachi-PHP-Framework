
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/object.h"
#include "kernel/memory.h"
#include "kernel/array.h"
#include "kernel/hash.h"
#include "kernel/fcall.h"
#include "kernel/operators.h"
#include "kernel/string.h"
#include "kernel/file.h"
#include "kernel/require.h"
#include "kernel/exception.h"


ZEPHIR_INIT_CLASS(hachi_0__closure) {

	ZEPHIR_REGISTER_CLASS(hachi, 0__closure, hachi, 0__closure, hachi_0__closure_method_entry, ZEND_ACC_FINAL_CLASS);

	return SUCCESS;

}

PHP_METHOD(hachi_0__closure, __invoke) {

	int ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_3 = NULL;
	zval *class_name = NULL, class_name_sub, is_exclude, t, require_path, exclude, spl_value, _0, inc_path, inc_path_for, is_found_file, *_1, _2$$3, _4$$5, _5$$5, _6$$5, _7$$5, _8$$6, _9$$6, _10$$6, _11$$7, _12$$7, _13$$7, _14$$8, *_15$$8, _16$$9, _17$$10, _18$$10, _19$$10, _20$$11, _21$$11, _22$$11, _23$$13, _24$$13, _25$$13;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&class_name_sub);
	ZVAL_UNDEF(&is_exclude);
	ZVAL_UNDEF(&t);
	ZVAL_UNDEF(&require_path);
	ZVAL_UNDEF(&exclude);
	ZVAL_UNDEF(&spl_value);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&inc_path);
	ZVAL_UNDEF(&inc_path_for);
	ZVAL_UNDEF(&is_found_file);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_4$$5);
	ZVAL_UNDEF(&_5$$5);
	ZVAL_UNDEF(&_6$$5);
	ZVAL_UNDEF(&_7$$5);
	ZVAL_UNDEF(&_8$$6);
	ZVAL_UNDEF(&_9$$6);
	ZVAL_UNDEF(&_10$$6);
	ZVAL_UNDEF(&_11$$7);
	ZVAL_UNDEF(&_12$$7);
	ZVAL_UNDEF(&_13$$7);
	ZVAL_UNDEF(&_14$$8);
	ZVAL_UNDEF(&_16$$9);
	ZVAL_UNDEF(&_17$$10);
	ZVAL_UNDEF(&_18$$10);
	ZVAL_UNDEF(&_19$$10);
	ZVAL_UNDEF(&_20$$11);
	ZVAL_UNDEF(&_21$$11);
	ZVAL_UNDEF(&_22$$11);
	ZVAL_UNDEF(&_23$$13);
	ZVAL_UNDEF(&_24$$13);
	ZVAL_UNDEF(&_25$$13);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &class_name);

	ZEPHIR_SEPARATE_PARAM(class_name);


	zephir_read_static_property_ce(&_0, hachi_app_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
	ZEPHIR_OBS_VAR(&exclude);
	zephir_array_fetch_string(&exclude, &_0, SL("spl_exclude"), PH_NOISY, "hachi/app.zep", 26 TSRMLS_CC);
	ZEPHIR_INIT_VAR(&is_exclude);
	ZVAL_BOOL(&is_exclude, 0);
	zephir_is_iterable(&exclude, 0, "hachi/app.zep", 39);
	ZEND_HASH_FOREACH_VAL(Z_ARRVAL_P(&exclude), _1)
	{
		ZEPHIR_INIT_NVAR(&spl_value);
		ZVAL_COPY(&spl_value, _1);
		ZEPHIR_CALL_FUNCTION(&_2$$3, "stripos", &_3, 16, class_name, &spl_value);
		zephir_check_call_status();
		if (!ZEPHIR_IS_FALSE_IDENTICAL(&_2$$3)) {
			ZEPHIR_INIT_NVAR(&is_exclude);
			ZVAL_BOOL(&is_exclude, 1);
			break;
		}
	} ZEND_HASH_FOREACH_END();
	ZEPHIR_INIT_NVAR(&spl_value);
	ZEPHIR_INIT_NVAR(&exclude);
	ZVAL_NULL(&exclude);
	if (!(zephir_is_true(&is_exclude))) {
		ZEPHIR_INIT_VAR(&is_found_file);
		ZVAL_BOOL(&is_found_file, 0);
		ZEPHIR_INIT_VAR(&_4$$5);
		ZEPHIR_INIT_VAR(&_5$$5);
		ZVAL_STRING(&_5$$5, "_");
		ZEPHIR_INIT_VAR(&_6$$5);
		ZVAL_STRING(&_6$$5, "/");
		zephir_fast_str_replace(&_4$$5, &_5$$5, &_6$$5, class_name TSRMLS_CC);
		ZEPHIR_CPY_WRT(class_name, &_4$$5);
		zephir_read_static_property_ce(&_7$$5, hachi_app_ce, SL("conf"), PH_NOISY_CC | PH_READONLY);
		ZEPHIR_OBS_VAR(&t);
		zephir_array_fetch_string(&t, &_7$$5, SL("www"), PH_NOISY, "hachi/app.zep", 46 TSRMLS_CC);
		ZEPHIR_INIT_NVAR(&_4$$5);
		ZVAL_STRING(&_4$$5, "%s/%s.php");
		ZEPHIR_CALL_FUNCTION(&require_path, "sprintf", NULL, 1, &_4$$5, &t, class_name);
		zephir_check_call_status();
		if ((zephir_file_exists(&require_path TSRMLS_CC) == SUCCESS)) {
			if (zephir_require_zval(&require_path TSRMLS_CC) == FAILURE) {
				RETURN_MM_NULL();
			}
			ZEPHIR_INIT_VAR(&_8$$6);
			ZEPHIR_INIT_VAR(&_9$$6);
			ZVAL_STRING(&_9$$6, "/");
			ZEPHIR_INIT_VAR(&_10$$6);
			ZVAL_STRING(&_10$$6, "_");
			zephir_fast_str_replace(&_8$$6, &_9$$6, &_10$$6, class_name TSRMLS_CC);
			ZEPHIR_CPY_WRT(class_name, &_8$$6);
			if (!(zephir_class_exists(class_name, 1 TSRMLS_CC))) {
				ZEPHIR_INIT_VAR(&_11$$7);
				object_init_ex(&_11$$7, zend_exception_get_default(TSRMLS_C));
				ZEPHIR_INIT_VAR(&_12$$7);
				ZVAL_STRING(&_12$$7, "Found class error: %s");
				ZEPHIR_CALL_FUNCTION(&_13$$7, "sprintf", NULL, 1, &_12$$7, class_name);
				zephir_check_call_status();
				ZEPHIR_CALL_METHOD(NULL, &_11$$7, "__construct", NULL, 13, &_13$$7);
				zephir_check_call_status();
				zephir_throw_exception_debug(&_11$$7, "hachi/app.zep", 52 TSRMLS_CC);
				ZEPHIR_MM_RESTORE();
				return;
			}
			ZEPHIR_INIT_NVAR(&is_found_file);
			ZVAL_BOOL(&is_found_file, 1);
		} else {
			ZEPHIR_CALL_FUNCTION(&_14$$8, "get_include_path", NULL, 19);
			zephir_check_call_status();
			ZEPHIR_INIT_VAR(&inc_path);
			zephir_fast_explode_str(&inc_path, SL(";"), &_14$$8, LONG_MAX TSRMLS_CC);
			zephir_is_iterable(&inc_path, 0, "hachi/app.zep", 72);
			ZEND_HASH_FOREACH_VAL(Z_ARRVAL_P(&inc_path), _15$$8)
			{
				ZEPHIR_INIT_NVAR(&inc_path_for);
				ZVAL_COPY(&inc_path_for, _15$$8);
				ZEPHIR_INIT_NVAR(&_16$$9);
				ZVAL_STRING(&_16$$9, "%s/%s.php");
				ZEPHIR_CALL_FUNCTION(&require_path, "sprintf", NULL, 1, &_16$$9, &inc_path_for, class_name);
				zephir_check_call_status();
				if ((zephir_file_exists(&require_path TSRMLS_CC) == SUCCESS)) {
					if (zephir_require_zval(&require_path TSRMLS_CC) == FAILURE) {
						RETURN_MM_NULL();
					}
					ZEPHIR_INIT_NVAR(&_17$$10);
					ZEPHIR_INIT_NVAR(&_18$$10);
					ZVAL_STRING(&_18$$10, "/");
					ZEPHIR_INIT_NVAR(&_19$$10);
					ZVAL_STRING(&_19$$10, "_");
					zephir_fast_str_replace(&_17$$10, &_18$$10, &_19$$10, class_name TSRMLS_CC);
					ZEPHIR_CPY_WRT(class_name, &_17$$10);
					if (!(zephir_class_exists(class_name, 1 TSRMLS_CC))) {
						ZEPHIR_INIT_NVAR(&_20$$11);
						object_init_ex(&_20$$11, zend_exception_get_default(TSRMLS_C));
						ZEPHIR_INIT_NVAR(&_21$$11);
						ZVAL_STRING(&_21$$11, "Not Found class error : %s");
						ZEPHIR_CALL_FUNCTION(&_22$$11, "sprintf", NULL, 1, &_21$$11, class_name);
						zephir_check_call_status();
						ZEPHIR_CALL_METHOD(NULL, &_20$$11, "__construct", NULL, 13, &_22$$11);
						zephir_check_call_status();
						zephir_throw_exception_debug(&_20$$11, "hachi/app.zep", 63 TSRMLS_CC);
						ZEPHIR_MM_RESTORE();
						return;
					}
					ZEPHIR_INIT_NVAR(&is_found_file);
					ZVAL_BOOL(&is_found_file, 1);
					break;
				} else {
					continue;
				}
			} ZEND_HASH_FOREACH_END();
			ZEPHIR_INIT_NVAR(&inc_path_for);
		}
		if (!(zephir_is_true(&is_found_file))) {
			ZEPHIR_INIT_VAR(&_23$$13);
			object_init_ex(&_23$$13, zend_exception_get_default(TSRMLS_C));
			ZEPHIR_INIT_VAR(&_24$$13);
			ZVAL_STRING(&_24$$13, "Not Found class : %s");
			ZEPHIR_CALL_FUNCTION(&_25$$13, "sprintf", NULL, 1, &_24$$13, class_name);
			zephir_check_call_status();
			ZEPHIR_CALL_METHOD(NULL, &_23$$13, "__construct", NULL, 13, &_25$$13);
			zephir_check_call_status();
			zephir_throw_exception_debug(&_23$$13, "hachi/app.zep", 74 TSRMLS_CC);
			ZEPHIR_MM_RESTORE();
			return;
		}
	}
	ZEPHIR_MM_RESTORE();

}

