
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/memory.h"
#include "kernel/string.h"
#include "kernel/object.h"
#include "kernel/fcall.h"
#include "kernel/file.h"
#include "kernel/require.h"
#include "kernel/exception.h"


ZEPHIR_INIT_CLASS(hachi_1__closure) {

	ZEPHIR_REGISTER_CLASS(hachi, 1__closure, hachi, 1__closure, hachi_1__closure_method_entry, ZEND_ACC_FINAL_CLASS);

	return SUCCESS;

}

PHP_METHOD(hachi_1__closure, __invoke) {

	int ZEPHIR_LAST_CALL_STATUS;
	zval *class_name = NULL, class_name_sub, t, require_path, _0, _1, _2, _3$$3, _4$$3, _5$$3, _6$$4, _7$$4, _8$$4, _9$$5, _10$$5, _11$$5;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&class_name_sub);
	ZVAL_UNDEF(&t);
	ZVAL_UNDEF(&require_path);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_2);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$3);
	ZVAL_UNDEF(&_6$$4);
	ZVAL_UNDEF(&_7$$4);
	ZVAL_UNDEF(&_8$$4);
	ZVAL_UNDEF(&_9$$5);
	ZVAL_UNDEF(&_10$$5);
	ZVAL_UNDEF(&_11$$5);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &class_name);

	ZEPHIR_SEPARATE_PARAM(class_name);


	ZEPHIR_INIT_VAR(&_0);
	ZEPHIR_INIT_VAR(&_1);
	ZVAL_STRING(&_1, "_");
	ZEPHIR_INIT_VAR(&_2);
	ZVAL_STRING(&_2, "/");
	zephir_fast_str_replace(&_0, &_1, &_2, class_name TSRMLS_CC);
	ZEPHIR_CPY_WRT(class_name, &_0);
	ZEPHIR_OBS_VAR(&t);
	zephir_read_static_property_ce(&t, hachi_run_ce, SL("conf"), PH_NOISY_CC);
	ZEPHIR_INIT_NVAR(&_0);
	ZVAL_STRING(&_0, "%s/%s.php");
	ZEPHIR_CALL_FUNCTION(&require_path, "sprintf", NULL, 6, &_0, &t, class_name);
	zephir_check_call_status();
	if ((zephir_file_exists(&require_path TSRMLS_CC) == SUCCESS)) {
		if (zephir_require_zval(&require_path TSRMLS_CC) == FAILURE) {
			RETURN_MM_NULL();
		}
		ZEPHIR_INIT_VAR(&_3$$3);
		ZEPHIR_INIT_VAR(&_4$$3);
		ZVAL_STRING(&_4$$3, "/");
		ZEPHIR_INIT_VAR(&_5$$3);
		ZVAL_STRING(&_5$$3, "_");
		zephir_fast_str_replace(&_3$$3, &_4$$3, &_5$$3, class_name TSRMLS_CC);
		ZEPHIR_CPY_WRT(class_name, &_3$$3);
		if (!(zephir_class_exists(class_name, 1 TSRMLS_CC))) {
			ZEPHIR_INIT_VAR(&_6$$4);
			object_init_ex(&_6$$4, zend_exception_get_default(TSRMLS_C));
			ZEPHIR_INIT_VAR(&_7$$4);
			ZVAL_STRING(&_7$$4, "Found class error: %s");
			ZEPHIR_CALL_FUNCTION(&_8$$4, "sprintf", NULL, 6, &_7$$4, class_name);
			zephir_check_call_status();
			ZEPHIR_CALL_METHOD(NULL, &_6$$4, "__construct", NULL, 11, &_8$$4);
			zephir_check_call_status();
			zephir_throw_exception_debug(&_6$$4, "hachi/run.zep", 40 TSRMLS_CC);
			ZEPHIR_MM_RESTORE();
			return;
		}
	} else {
		ZEPHIR_INIT_VAR(&_9$$5);
		object_init_ex(&_9$$5, zend_exception_get_default(TSRMLS_C));
		ZEPHIR_INIT_VAR(&_10$$5);
		ZVAL_STRING(&_10$$5, "Not Found class : %s");
		ZEPHIR_CALL_FUNCTION(&_11$$5, "sprintf", NULL, 6, &_10$$5, class_name);
		zephir_check_call_status();
		ZEPHIR_CALL_METHOD(NULL, &_9$$5, "__construct", NULL, 11, &_11$$5);
		zephir_check_call_status();
		zephir_throw_exception_debug(&_9$$5, "hachi/run.zep", 43 TSRMLS_CC);
		ZEPHIR_MM_RESTORE();
		return;
	}
	ZEPHIR_MM_RESTORE();

}

