
#ifdef HAVE_CONFIG_H
#include "../ext_config.h"
#endif

#include <php.h>
#include "../php_ext.h"
#include "../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/object.h"
#include "kernel/memory.h"
#include "kernel/string.h"
#include "kernel/operators.h"
#include "kernel/fcall.h"
#include "kernel/hash.h"
#include "kernel/array.h"


ZEPHIR_INIT_CLASS(Hachi_Routes) {

	ZEPHIR_REGISTER_CLASS(Hachi, Routes, hachi, routes, hachi_routes_method_entry, 0);

	zend_declare_property_null(hachi_routes_ce, SL("include_method_array"), ZEND_ACC_PRIVATE TSRMLS_CC);

	zend_declare_property_null(hachi_routes_ce, SL("route_group"), ZEND_ACC_PRIVATE TSRMLS_CC);

	return SUCCESS;

}

PHP_METHOD(Hachi_Routes, uriPraser) {

	zend_bool _26$$10, _27$$11, _30$$12;
	zend_string *_19;
	zend_ulong _18;
	int ZEPHIR_LAST_CALL_STATUS, uri_counter = 0, code = 0, i = 0, _28$$11;
	zephir_fcall_cache_entry *_6 = NULL, *_21 = NULL;
	zval route_group, method_arr, param_get, param_post, params, ret, _39;
	zval *uri_param = NULL, *route_group_param = NULL, *method_arr_param = NULL, *param_get_param = NULL, *param_post_param = NULL, group, controller, action, uri_array, p, v, uri_array_length, _0, _1, _7, _8, _13, _14, _15, _16, *_17, _33, _34, _35, _36, _37, _38, _2$$3, _3$$3, _4$$3, _5$$3, _9$$4, _10$$4, _11$$4, _12$$4, _20$$5, _22$$6, _23$$6, _24$$6, _25$$6, _29$$11, _31$$13, _32$$13;
	zval uri, pattern;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&uri);
	ZVAL_UNDEF(&pattern);
	ZVAL_UNDEF(&group);
	ZVAL_UNDEF(&controller);
	ZVAL_UNDEF(&action);
	ZVAL_UNDEF(&uri_array);
	ZVAL_UNDEF(&p);
	ZVAL_UNDEF(&v);
	ZVAL_UNDEF(&uri_array_length);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_1);
	ZVAL_UNDEF(&_7);
	ZVAL_UNDEF(&_8);
	ZVAL_UNDEF(&_13);
	ZVAL_UNDEF(&_14);
	ZVAL_UNDEF(&_15);
	ZVAL_UNDEF(&_16);
	ZVAL_UNDEF(&_33);
	ZVAL_UNDEF(&_34);
	ZVAL_UNDEF(&_35);
	ZVAL_UNDEF(&_36);
	ZVAL_UNDEF(&_37);
	ZVAL_UNDEF(&_38);
	ZVAL_UNDEF(&_2$$3);
	ZVAL_UNDEF(&_3$$3);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$3);
	ZVAL_UNDEF(&_9$$4);
	ZVAL_UNDEF(&_10$$4);
	ZVAL_UNDEF(&_11$$4);
	ZVAL_UNDEF(&_12$$4);
	ZVAL_UNDEF(&_20$$5);
	ZVAL_UNDEF(&_22$$6);
	ZVAL_UNDEF(&_23$$6);
	ZVAL_UNDEF(&_24$$6);
	ZVAL_UNDEF(&_25$$6);
	ZVAL_UNDEF(&_29$$11);
	ZVAL_UNDEF(&_31$$13);
	ZVAL_UNDEF(&_32$$13);
	ZVAL_UNDEF(&route_group);
	ZVAL_UNDEF(&method_arr);
	ZVAL_UNDEF(&param_get);
	ZVAL_UNDEF(&param_post);
	ZVAL_UNDEF(&params);
	ZVAL_UNDEF(&ret);
	ZVAL_UNDEF(&_39);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 5, 0, &uri_param, &route_group_param, &method_arr_param, &param_get_param, &param_post_param);

	zephir_get_strval(&uri, uri_param);
	zephir_get_arrval(&route_group, route_group_param);
	zephir_get_arrval(&method_arr, method_arr_param);
	zephir_get_arrval(&param_get, param_get_param);
	zephir_get_arrval(&param_post, param_post_param);


	zephir_update_property_zval(this_ptr, SL("include_method_array"), &method_arr);
	zephir_update_property_zval(this_ptr, SL("route_group"), &route_group);
	uri_counter = 0;
	code = 0;
	ZEPHIR_INIT_VAR(&group);
	ZVAL_NULL(&group);
	ZEPHIR_INIT_VAR(&controller);
	ZVAL_NULL(&controller);
	ZEPHIR_INIT_VAR(&action);
	ZVAL_NULL(&action);
	ZEPHIR_INIT_VAR(&params);
	array_init(&params);
	ZEPHIR_INIT_VAR(&_0);
	ZVAL_STRING(&_0, "?");
	ZEPHIR_INIT_VAR(&_1);
	zephir_fast_strpos(&_1, &uri, &_0, 0 );
	if (ZEPHIR_GT_LONG(&_1, 0)) {
		ZEPHIR_INIT_VAR(&_2$$3);
		ZVAL_STRING(&_2$$3, "?");
		ZEPHIR_INIT_VAR(&_3$$3);
		zephir_fast_strpos(&_3$$3, &uri, &_2$$3, 0 );
		ZVAL_LONG(&_4$$3, 0);
		ZEPHIR_CALL_FUNCTION(&_5$$3, "mb_substr", &_6, 14, &uri, &_4$$3, &_3$$3);
		zephir_check_call_status();
		zephir_get_strval(&uri, &_5$$3);
	}
	ZEPHIR_INIT_VAR(&_7);
	ZVAL_STRING(&_7, "&");
	ZEPHIR_INIT_VAR(&_8);
	zephir_fast_strpos(&_8, &uri, &_7, 0 );
	if (ZEPHIR_GT_LONG(&_8, 0)) {
		ZEPHIR_INIT_VAR(&_9$$4);
		ZVAL_STRING(&_9$$4, "&");
		ZEPHIR_INIT_VAR(&_10$$4);
		zephir_fast_strpos(&_10$$4, &uri, &_9$$4, 0 );
		ZVAL_LONG(&_11$$4, 0);
		ZEPHIR_CALL_FUNCTION(&_12$$4, "mb_substr", &_6, 14, &uri, &_11$$4, &_10$$4);
		zephir_check_call_status();
		zephir_get_strval(&uri, &_12$$4);
	}
	ZEPHIR_CALL_METHOD(&_13, this_ptr, "__dealroutemethod", NULL, 15, &uri);
	zephir_check_call_status();
	zephir_get_strval(&uri, &_13);
	ZEPHIR_INIT_VAR(&_14);
	ZEPHIR_INIT_VAR(&_15);
	ZVAL_STRING(&_15, "/");
	zephir_fast_trim(&_14, &uri, &_15, ZEPHIR_TRIM_LEFT TSRMLS_CC);
	zephir_get_strval(&uri, &_14);
	zephir_read_property(&_16, this_ptr, SL("route_group"), PH_NOISY_CC | PH_READONLY);
	zephir_is_iterable(&_16, 0, "hachi/routes.zep", 60);
	ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&_16), _18, _19, _17)
	{
		ZEPHIR_INIT_NVAR(&p);
		if (_19 != NULL) { 
			ZVAL_STR_COPY(&p, _19);
		} else {
			ZVAL_LONG(&p, _18);
		}
		ZEPHIR_INIT_NVAR(&v);
		ZVAL_COPY(&v, _17);
		ZEPHIR_CALL_FUNCTION(&_20$$5, "stripos", &_21, 16, &uri, &p);
		zephir_check_call_status();
		if (ZEPHIR_IS_LONG_IDENTICAL(&_20$$5, 0)) {
			ZEPHIR_CPY_WRT(&group, &v);
			ZVAL_LONG(&_22$$6, zephir_fast_strlen_ev(&p));
			ZEPHIR_CALL_FUNCTION(&_23$$6, "mb_substr", &_6, 14, &uri, &_22$$6);
			zephir_check_call_status();
			zephir_get_strval(&uri, &_23$$6);
			ZEPHIR_INIT_NVAR(&_24$$6);
			ZEPHIR_INIT_NVAR(&_25$$6);
			ZVAL_STRING(&_25$$6, "/");
			zephir_fast_trim(&_24$$6, &uri, &_25$$6, ZEPHIR_TRIM_LEFT TSRMLS_CC);
			zephir_get_strval(&uri, &_24$$6);
		}
	} ZEND_HASH_FOREACH_END();
	ZEPHIR_INIT_NVAR(&v);
	ZEPHIR_INIT_NVAR(&p);
	ZEPHIR_INIT_VAR(&uri_array);
	zephir_fast_explode_str(&uri_array, SL("/"), &uri, LONG_MAX TSRMLS_CC);
	if (zephir_array_isset_long(&uri_array, uri_counter)) {
		ZEPHIR_OBS_NVAR(&controller);
		zephir_array_fetch_long(&controller, &uri_array, uri_counter, PH_NOISY, "hachi/routes.zep", 63 TSRMLS_CC);
	} else {
		ZEPHIR_INIT_NVAR(&controller);
		ZVAL_STRING(&controller, "welcome");
	}
	if (ZEPHIR_IS_EMPTY(&controller)) {
		ZEPHIR_INIT_NVAR(&controller);
		ZVAL_STRING(&controller, "welcome");
	}
	if (zephir_array_isset_long(&uri_array, (uri_counter + 1))) {
		ZEPHIR_OBS_NVAR(&action);
		zephir_array_fetch_long(&action, &uri_array, (uri_counter + 1), PH_NOISY, "hachi/routes.zep", 72 TSRMLS_CC);
		ZEPHIR_INIT_VAR(&uri_array_length);
		ZVAL_LONG(&uri_array_length, zephir_fast_count_int(&uri_array TSRMLS_CC));
		_26$$10 = ZEPHIR_GT_LONG(&uri_array_length, ((uri_counter + 2)));
		if (_26$$10) {
			_26$$10 = ZEPHIR_LT_LONG(&uri_array_length, 101);
		}
		if (_26$$10) {
			ZEPHIR_CPY_WRT(&_29$$11, &uri_array_length);
			_28$$11 = (uri_counter + 2);
			_27$$11 = 0;
			if (ZEPHIR_GE_LONG(&_29$$11, _28$$11)) {
				while (1) {
					if (_27$$11) {
						_28$$11 += 2;
						if (!(ZEPHIR_GE_LONG(&_29$$11, _28$$11))) {
							break;
						}
					} else {
						_27$$11 = 1;
					}
					i = _28$$11;
					_30$$12 = zephir_array_isset_long(&uri_array, i);
					if (_30$$12) {
						_30$$12 = zephir_array_isset_long(&uri_array, (i + 1));
					}
					if (_30$$12) {
						zephir_array_fetch_long(&_31$$13, &uri_array, (i + 1), PH_NOISY | PH_READONLY, "hachi/routes.zep", 80 TSRMLS_CC);
						ZEPHIR_OBS_NVAR(&_32$$13);
						zephir_array_fetch_long(&_32$$13, &uri_array, i, PH_NOISY, "hachi/routes.zep", 80 TSRMLS_CC);
						zephir_array_update_zval(&params, &_32$$13, &_31$$13, PH_COPY | PH_SEPARATE);
					}
				}
			}
		}
	} else {
		ZEPHIR_INIT_NVAR(&action);
		ZVAL_STRING(&action, "index");
	}
	if (ZEPHIR_IS_EMPTY(&action)) {
		ZEPHIR_INIT_NVAR(&action);
		ZVAL_STRING(&action, "index");
	}
	ZEPHIR_CALL_FUNCTION(&_33, "array_merge", NULL, 17, &params, &param_get, &param_post);
	zephir_check_call_status();
	ZEPHIR_CPY_WRT(&params, &_33);
	ZEPHIR_INIT_VAR(&pattern);
	ZVAL_STRING(&pattern, "/^[A-Za-z0-9]+$/");
	ZEPHIR_INIT_VAR(&_34);
	ZEPHIR_INIT_VAR(&_35);
	zephir_preg_match(&_35, &pattern, &controller, &_34, 0, 0 , 0  TSRMLS_CC);
	if (!(zephir_is_true(&_35))) {
		code = 10001;
	}
	ZEPHIR_INIT_VAR(&_36);
	ZEPHIR_INIT_VAR(&_37);
	zephir_preg_match(&_37, &pattern, &action, &_36, 0, 0 , 0  TSRMLS_CC);
	if (!(zephir_is_true(&_37))) {
		code = 10002;
	}
	ZEPHIR_INIT_VAR(&ret);
	zephir_create_array(&ret, 5, 0 TSRMLS_CC);
	ZEPHIR_INIT_VAR(&_38);
	ZVAL_LONG(&_38, code);
	zephir_array_update_string(&ret, SL("code"), &_38, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&ret, SL("group"), &group, PH_COPY | PH_SEPARATE);
	ZEPHIR_INIT_NVAR(&_38);
	zephir_ucfirst(&_38, &controller);
	zephir_array_update_string(&ret, SL("controller"), &_38, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&ret, SL("action"), &action, PH_COPY | PH_SEPARATE);
	ZEPHIR_INIT_VAR(&_39);
	zephir_create_array(&_39, 3, 0 TSRMLS_CC);
	zephir_array_update_string(&_39, SL("query"), &params, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&_39, SL("get"), &param_get, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&_39, SL("post"), &param_post, PH_COPY | PH_SEPARATE);
	zephir_array_update_string(&ret, SL("params"), &_39, PH_COPY | PH_SEPARATE);
	RETURN_CTOR(ret);

}

PHP_METHOD(Hachi_Routes, __dealRouteMethod) {

	zend_string *_3;
	zend_ulong _2;
	int ZEPHIR_LAST_CALL_STATUS;
	zephir_fcall_cache_entry *_6 = NULL;
	zval *uri_param = NULL, ret, p, v, _0, *_1, _4$$3, _5$$3;
	zval uri, pattern$$3, replace$$3;
	ZEPHIR_INIT_THIS();

	ZVAL_UNDEF(&uri);
	ZVAL_UNDEF(&pattern$$3);
	ZVAL_UNDEF(&replace$$3);
	ZVAL_UNDEF(&ret);
	ZVAL_UNDEF(&p);
	ZVAL_UNDEF(&v);
	ZVAL_UNDEF(&_0);
	ZVAL_UNDEF(&_4$$3);
	ZVAL_UNDEF(&_5$$3);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 0, &uri_param);

	zephir_get_strval(&uri, uri_param);


	ZEPHIR_CPY_WRT(&ret, &uri);
	zephir_read_property(&_0, this_ptr, SL("include_method_array"), PH_NOISY_CC | PH_READONLY);
	zephir_is_iterable(&_0, 0, "hachi/routes.zep", 130);
	ZEND_HASH_FOREACH_KEY_VAL(Z_ARRVAL_P(&_0), _2, _3, _1)
	{
		ZEPHIR_INIT_NVAR(&p);
		if (_3 != NULL) { 
			ZVAL_STR_COPY(&p, _3);
		} else {
			ZVAL_LONG(&p, _2);
		}
		ZEPHIR_INIT_NVAR(&v);
		ZVAL_COPY(&v, _1);
		zephir_get_strval(&pattern$$3, &p);
		zephir_get_strval(&replace$$3, &v);
		ZEPHIR_INIT_NVAR(&_4$$3);
		ZEPHIR_INIT_NVAR(&_5$$3);
		zephir_preg_match(&_5$$3, &pattern$$3, &uri, &_4$$3, 0, 0 , 0  TSRMLS_CC);
		if (zephir_is_true(&_5$$3)) {
			ZEPHIR_CALL_FUNCTION(&ret, "preg_replace", &_6, 18, &pattern$$3, &replace$$3, &uri);
			zephir_check_call_status();
			break;
		}
	} ZEND_HASH_FOREACH_END();
	ZEPHIR_INIT_NVAR(&v);
	ZEPHIR_INIT_NVAR(&p);
	RETURN_CCTOR(ret);

}

